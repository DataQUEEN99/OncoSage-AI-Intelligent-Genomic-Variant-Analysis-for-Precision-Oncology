/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';

interface DnaHelixProps {
  interactive?: boolean;
  colorPrimary?: string; // e.g. '#06b6d4' cyan
  colorSecondary?: string; // e.g. '#a855f7' purple
  speed?: number;
  density?: number;
}

export default function DnaHelix({
  interactive = true,
  colorPrimary = '#00f0ff',
  colorSecondary = '#b026ff',
  speed = 0.008,
  density = 0.5
}: DnaHelixProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let rotation = 0;

    // Handle Resize
    const resizeCanvas = () => {
      const parent = canvas.parentElement;
      if (parent) {
        canvas.width = parent.clientWidth || 300;
        canvas.height = parent.clientHeight || 300;
      }
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Track Mouse for interaction
    const handleMouseMove = (e: MouseEvent) => {
      if (!interactive) return;
      const rect = canvas.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) return;
      // Normalize mouse positions
      mouseRef.current.targetX = (e.clientX - rect.left) / rect.width - 0.5;
      mouseRef.current.targetY = (e.clientY - rect.top) / rect.height - 0.5;
    };
    canvas.addEventListener('mousemove', handleMouseMove);

    // Simple Render Loop
    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const w = canvas.width;
      const h = canvas.height;
      if (w <= 0 || h <= 0) {
        animationFrameId = requestAnimationFrame(render);
        return;
      }

      const centerY = h / 2;
      const amplitude = h * 0.28; // height of the spiral wave
      const wavelength = 320; // width of a full spiral wave
      const numNodes = Math.max(2, Math.floor((w / 20) * density)); // spacing out nodes

      // Smooth mouse tracking
      const mx = isFinite(mouseRef.current.x) ? mouseRef.current.x : 0;
      const my = isFinite(mouseRef.current.y) ? mouseRef.current.y : 0;
      const mTargetX = isFinite(mouseRef.current.targetX) ? mouseRef.current.targetX : 0;
      const mTargetY = isFinite(mouseRef.current.targetY) ? mouseRef.current.targetY : 0;

      mouseRef.current.x = mx + (mTargetX - mx) * 0.1;
      mouseRef.current.y = my + (mTargetY - my) * 0.1;

      // Update rotation
      rotation += speed + (mouseRef.current.x * 0.05);
      if (!isFinite(rotation)) rotation = 0;

      // Node structure for double helix
      const helixA: { x: number; y: number; z: number }[] = [];
      const helixB: { x: number; y: number; z: number }[] = [];

      for (let i = 0; i <= numNodes; i++) {
        const xFactor = i / numNodes;
        const x = xFactor * w;
        
        // Phase shifts creating the spiraling double strand
        const angle = (x / wavelength) * Math.PI * 2 + rotation;
        
        // Adding depth logic (Z) for 3D illusion
        const zA = Math.sin(angle);
        const zB = Math.sin(angle + Math.PI); // exact opposite phase
        
        const yA = centerY + Math.cos(angle) * amplitude * (1 + mouseRef.current.y * 0.6);
        const yB = centerY + Math.cos(angle + Math.PI) * amplitude * (1 + mouseRef.current.y * 0.6);

        helixA.push({ x, y: yA, z: zA });
        helixB.push({ x, y: yB, z: zB });
      }

      // 1. Draw connection rungs first (draw them with low Z coordinates in the back, then high Z in front)
      for (let i = 0; i < helixA.length; i++) {
        const pA = helixA[i];
        const pB = helixB[i];

        if (!isFinite(pA.x) || !isFinite(pA.y) || !isFinite(pB.x) || !isFinite(pB.y)) {
          continue;
        }

        // Draw nucleotide base pairs (rungs)
        const avgZ = (pA.z + pB.z) / 2;
        const alpha = Math.max(0.15, (avgZ + 1) / 2); // opaque in front, translucent in back

        ctx.beginPath();
        ctx.moveTo(pA.x, pA.y);
        ctx.lineTo(pB.x, pB.y);

        // Tech-style glowing line
        const gradient = ctx.createLinearGradient(pA.x, pA.y, pB.x, pB.y);
        gradient.addColorStop(0, hexToRgba(colorPrimary, alpha * 0.8));
        gradient.addColorStop(0.5, 'rgba(100, 255, 218, 0.2)');
        gradient.addColorStop(1, hexToRgba(colorSecondary, alpha * 0.8));

        ctx.strokeStyle = gradient;
        ctx.lineWidth = Math.max(1, (avgZ + 1.2) * 2);
        ctx.stroke();

        // Little nucleotide joint nodes
        if (i % 2 === 0) {
          ctx.beginPath();
          ctx.arc((pA.x + pB.x) / 2, (pA.y + pB.y) / 2, Math.max(1.5, (avgZ + 1) * 2.5), 0, Math.PI * 2);
          ctx.fillStyle = `rgba(100, 255, 255, ${alpha * 0.5})`;
          ctx.shadowBlur = 10;
          ctx.shadowColor = '#00f0ff';
          ctx.fill();
          ctx.shadowBlur = 0; // reset
        }
      }

      // 2. Draw backbone strands with depth awareness (smaller size/alpha for negative Z)
      ctx.lineWidth = 3.5;
      
      // Strand A
      for (let i = 0; i < helixA.length - 1; i++) {
        const p1 = helixA[i];
        const p2 = helixA[i+1];

        if (!isFinite(p1.x) || !isFinite(p1.y) || !isFinite(p2.x) || !isFinite(p2.y)) {
          continue;
        }

        const alpha = Math.max(0.2, (p1.z + p2.z) / 4 + 0.5);

        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.strokeStyle = hexToRgba(colorPrimary, alpha);
        ctx.shadowBlur = p1.z > 0 ? 15 : 0;
        ctx.shadowColor = colorPrimary;
        ctx.stroke();
        ctx.shadowBlur = 0;

        // Backbone sugar nodes
        if (i % 1 === 0) {
          ctx.beginPath();
          ctx.arc(p1.x, p1.y, Math.max(2.5, (p1.z + 1.2) * 4), 0, Math.PI * 2);
          ctx.fillStyle = p1.z > 0 ? colorPrimary : hexToRgba(colorPrimary, 0.4);
          ctx.fill();
        }
      }

      // Strand B
      for (let i = 0; i < helixB.length - 1; i++) {
        const p1 = helixB[i];
        const p2 = helixB[i+1];

        if (!isFinite(p1.x) || !isFinite(p1.y) || !isFinite(p2.x) || !isFinite(p2.y)) {
          continue;
        }

        const alpha = Math.max(0.2, (p1.z + p2.z) / 4 + 0.5);

        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.strokeStyle = hexToRgba(colorSecondary, alpha);
        ctx.shadowBlur = p1.z > 0 ? 15 : 0;
        ctx.shadowColor = colorSecondary;
        ctx.stroke();
        ctx.shadowBlur = 0;

        // Backbone sugar nodes
        if (i % 1 === 0) {
          ctx.beginPath();
          ctx.arc(p1.x, p1.y, Math.max(2.5, (p1.z + 1.2) * 4), 0, Math.PI * 2);
          ctx.fillStyle = p1.z > 0 ? colorSecondary : hexToRgba(colorSecondary, 0.4);
          ctx.fill();
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      canvas.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, [interactive, colorPrimary, colorSecondary, speed, density]);

  return (
    <canvas 
      ref={canvasRef} 
      id="dna-helix-canvas"
      className="w-full h-full block relative cursor-crosshair drop-shadow-lg"
      style={{ background: 'transparent' }}
    />
  );
}

// Utility to convert Hex to RGBA
function hexToRgba(hex: string, alpha = 1): string {
  const cleanHex = hex.replace('#', '');
  const r = parseInt(cleanHex.substring(0, 2), 16);
  const g = parseInt(cleanHex.substring(2, 4), 16);
  const b = parseInt(cleanHex.substring(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
