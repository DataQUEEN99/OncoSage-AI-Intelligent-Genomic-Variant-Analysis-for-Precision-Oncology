/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface GenomicVariant {
  id: string;
  gene: string;
  chromosome: string;
  position: number;
  refAllele: string;
  altAllele: string;
  consequence: 'Missense' | 'Nonsense' | 'Frameshift' | 'Splice Site' | 'Synonymous';
  caddScore: number;       // Combined Annotation Dependent Depletion (0-40)
  polyphenScore: number;   // PolyPhen-2 score (0-1)
  siftScore: number;       // SIFT score (0-1)
  alleleFrequency: number; // gnomAD Allele Frequency
  revelScore: number;      // REVEL score for missense variants (0-1)
  conservationScore: number; // GERP++ Conservation Score (0-1)
  pathogenicity?: 'Benign' | 'Pathogenic' | 'VUS';
  confidence?: number;     // Prediction confidence %
  riskLevel?: 'Low' | 'Medium' | 'High' | 'Critical';
  clinicalInterpretation?: string;
  timestamp?: string;
}

export interface ModelMetrics {
  accuracy: number;
  auc: number;
  precision: number;
  recall: number;
  f1Score: number;
  rocCurve: { fpr: number; tpr: number }[];
  confusionMatrix: {
    truePositive: number;
    falsePositive: number;
    trueNegative: number;
    falseNegative: number;
  };
}

export interface FeatureImportance {
  featureName: string;
  score: number;
  shapValue: number; // Average impact on model output
  description: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  genomicContext?: {
    gene?: string;
    variantId?: string;
    prediction?: string;
  };
}

export interface PredictionJob {
  id: string;
  name: string;
  date: string;
  variantCount: number;
  status: 'Completed' | 'Processing' | 'Failed';
  modelUsed: string;
  results: GenomicVariant[];
}
