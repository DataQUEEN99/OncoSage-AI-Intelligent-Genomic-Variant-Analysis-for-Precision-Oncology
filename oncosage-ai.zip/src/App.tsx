/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import {
  Activity,
  Award,
  Search,
  BookOpen,
  Cpu,
  Database,
  Download,
  FileText,
  HelpCircle,
  History,
  Info,
  Maximize2,
  MessageSquare,
  Layers,
  Settings,
  Share2,
  Sparkles,
  TrendingUp,
  UploadCloud,
  User,
  X,
  AlertTriangle,
  Play,
  RotateCcw,
  CheckCircle,
  Copy,
  ChevronRight,
  Filter,
  Flame,
  ArrowRight,
  ExternalLink,
  Shield,
  Dna
} from "lucide-react";
import DnaHelix from "./components/DnaHelix";
import { GenomicVariant, ModelMetrics, FeatureImportance, ChatMessage, PredictionJob } from "./types";
import { sampleVariants, mockFeatureImportances, defaultModelMetrics, initialJobs, sampleUserDatabase } from "./data";

export default function App() {
  // Navigation & Screens
  const [showWorkstation, setShowWorkstation] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>("dashboard");

  // User & Settings State
  const [userProfile, setUserProfile] = useState(sampleUserDatabase.profile);
  const [userSettings, setUserSettings] = useState(sampleUserDatabase.settings);
  const [activeModel, setActiveModel] = useState<string>("OncoSage-XGBoost Neural V3");
  const [thresholdValue, setThresholdValue] = useState<number>(0.65);
  const [isLightMode, setIsLightMode] = useState<boolean>(false);

  // Genomic State
  const [variantsList, setVariantsList] = useState<GenomicVariant[]>(sampleVariants);
  const [jobsList, setJobsList] = useState<PredictionJob[]>(initialJobs);
  const [selectedVariantId, setSelectedVariantId] = useState<string | null>("chr17:g.7577120G>A");
  
  // Filtering & Search
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [consequenceFilter, setConsequenceFilter] = useState<string>("ALL");
  const [riskFilter, setRiskFilter] = useState<string>("ALL");

  // Chat Interface State
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([
    {
      id: "init-msg",
      sender: "assistant",
      text: "### Clinical Assist Initiated\n\nWelcome back, **Dr. Vance**. I have cataloged your tumor variant panels. Ask me anything relative to **CADD pathogenicity ranges**, **TP53 suppressor integrity**, or matched oncology therapeutics for somatic mutation panels.",
      timestamp: "10:32 UTC"
    }
  ]);
  const [chatInput, setChatInput] = useState<string>("");
  const [isTyping, setIsTyping] = useState<boolean>(false);

  // Modals & Upload UI State
  const [showAddVariantModal, setShowAddVariantModal] = useState<boolean>(false);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);
  const [showExportModal, setShowExportModal] = useState<boolean>(false);
  const [exportReportType, setExportReportType] = useState<string>("clinical");
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" | "info" } | null>(null);

  // Single active variant helper
  const activeVariant = variantsList.find(v => v.id === selectedVariantId) || variantsList[0];

  // Quick Stats State computed dynamically from local variants
  const totalScannedCount = variantsList.length;
  const criticalCount = variantsList.filter(v => v.riskLevel === "Critical" || v.riskLevel === "High").length;
  const pathogenicRatio = Math.round((variantsList.filter(v => v.pathogenicity === "Pathogenic").length / totalScannedCount) * 100) || 0;

  // New Custom Variant Form state
  const [newVarGene, setNewVarGene] = useState("EGFR");
  const [newVarChr, setNewVarChr] = useState("Chr7");
  const [newVarPos, setNewVarPos] = useState(55241712);
  const [newVarRef, setNewVarRef] = useState("C");
  const [newVarAlt, setNewVarAlt] = useState("A");
  const [newVarConsequence, setNewVarConsequence] = useState("Missense");
  const [newVarCadd, setNewVarCadd] = useState(25.4);
  const [newVarRevel, setNewVarRevel] = useState(0.81);
  const [newVarPolyPhen, setNewVarPolyPhen] = useState(0.92);
  const [newVarSift, setNewVarSift] = useState(0.02);
  const [newVarGnomad, setNewVarGnomad] = useState(0.00004);
  const [newVarConservation, setNewVarConservation] = useState(0.84);
  const [isSubmittingVariant, setIsSubmittingVariant] = useState(false);

  // Trigger brief visual toasts
  const triggerToast = (message: string, type: "success" | "error" | "info" = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  // Synchronize predictions based on updated model choices, thresholds, and custom weights
  const [isRecalculating, setIsRecalculating] = useState<boolean>(false);

  // Real API calls to execute Variant pathogenicity calculations
  const handleRecalculatePredictions = async (variantsToPredict = variantsList, showNotification = true) => {
    setIsRecalculating(true);
    try {
      const response = await fetch("/api/prediction", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          variants: variantsToPredict,
          modelUsed: activeModel,
          threshold: thresholdValue,
          weights: {
            revel: userSettings.revelWeight,
            cadd: userSettings.caddWeight,
            gnomad: userSettings.gnomadWeight,
            polyphen: userSettings.polyphenWeight,
            sift: userSettings.siftWeight
          }
        })
      });
      const data = await response.json();
      if (data.success && data.results) {
        setVariantsList(data.results);
        if (showNotification) {
          triggerToast(`Calibrated ${data.results.length} predictions using ${activeModel}`, "success");
        }
      } else {
        throw new Error(data.error || "Model returned invalid state.");
      }
    } catch (error: any) {
      console.error(error);
      triggerToast(`Failsafe predictive engine triggered: ${error.message}`, "info");
    } finally {
      setIsRecalculating(false);
    }
  };

  // Re-run whenever calculations variables shift
  useEffect(() => {
    handleRecalculatePredictions(variantsList, false);
  }, [activeModel, thresholdValue, userSettings.revelWeight, userSettings.caddWeight, userSettings.gnomadWeight, userSettings.polyphenWeight, userSettings.siftWeight]);

  // Handle manual additions
  const handleAddCustomVariant = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmittingVariant(true);

    const tempVariant = {
      id: `${newVarChr.toLowerCase()}:g.${newVarPos}${newVarRef}>${newVarAlt}`,
      gene: newVarGene.toUpperCase(),
      chromosome: newVarChr,
      position: Number(newVarPos),
      refAllele: newVarRef.toUpperCase(),
      altAllele: newVarAlt.toUpperCase(),
      consequence: newVarConsequence,
      caddScore: Number(newVarCadd),
      revelScore: Number(newVarRevel),
      polyphenScore: Number(newVarPolyPhen),
      siftScore: Number(newVarSift),
      alleleFrequency: Number(newVarGnomad),
      conservationScore: Number(newVarConservation),
      clinicalInterpretation: ""
    };

    try {
      // Fetch calculation
      const response = await fetch("/api/prediction", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          variants: [tempVariant],
          modelUsed: activeModel,
          threshold: thresholdValue
        })
      });
      const data = await response.json();
      if (data.success && data.results && data.results.length > 0) {
        const calculatedVar = data.results[0];
        
        // Let's trigger clinical summary annotation securely from server
        const interpretationResponse = await fetch("/api/generate-interpretation", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ variant: calculatedVar })
        });
        const interpretData = await interpretationResponse.json();
        if (interpretData.success) {
          calculatedVar.clinicalInterpretation = interpretData.interpretation;
        }

        setVariantsList(prev => [calculatedVar, ...prev]);
        setSelectedVariantId(calculatedVar.id);
        
        // Add prediction jobs record entry
        const newJob: PredictionJob = {
          id: `JOB-${Math.random().toString(36).substr(2, 5).toUpperCase()}`,
          name: `Manual Screening Variant Entry - ${calculatedVar.gene}`,
          date: new Date().toLocaleString(),
          variantCount: 1,
          status: "Completed",
          modelUsed: activeModel,
          results: [calculatedVar]
        };
        setJobsList(prev => [newJob, ...prev]);

        triggerToast(`Genomic variant ${calculatedVar.id} computed successfully!`, "success");
        setShowAddVariantModal(false);
      }
    } catch (err: any) {
      console.error(err);
      triggerToast(`Failed running pathogenicity model.`, "error");
    } finally {
      setIsSubmittingVariant(false);
    }
  };

  // Chat interface helper calling server
  const handleSendChatMessage = async (presetText?: string) => {
    const textToSend = presetText || chatInput;
    if (!textToSend.trim()) return;

    const userMsg: ChatMessage = {
      id: `chat-${Date.now()}`,
      sender: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatHistory(prev => [...prev, userMsg]);
    if (!presetText) setChatInput("");
    setIsTyping(true);

    try {
      const response = await fetch("/api/research-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: textToSend,
          history: chatHistory,
          genomicContext: activeVariant
        })
      });
      const data = await response.json();
      
      const botMsg: ChatMessage = {
        id: `chat-bot-${Date.now()}`,
        sender: "assistant",
        text: data.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setChatHistory(prev => [...prev, botMsg]);
    } catch (err: any) {
      console.error(err);
      const errMsg: ChatMessage = {
        id: `chat-bot-${Date.now()}`,
        sender: "assistant",
        text: `### Pipeline offline\n\nI encountered structural network limits mapping clinical archives. Try searching for "TP53" or "BRAF V600E".`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setChatHistory(prev => [...prev, errMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  // Drag and Drop implementation
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    setUploadStatus("analyzing");
    
    // Simulate parse times for biotech CSV genomic lists
    setTimeout(() => {
      // Append some extra interesting custom variants to demonstrate list loading file parsing
      const uploadedMockVariantsList: GenomicVariant[] = [
        {
          id: "chr3:g.10183318C>T",
          gene: "VHL",
          chromosome: "Chr3",
          position: 10183318,
          refAllele: "C",
          altAllele: "T",
          consequence: "Missense",
          caddScore: 23.9,
          polyphenScore: 0.89,
          siftScore: 0.04,
          alleleFrequency: 0.000008,
          revelScore: 0.72,
          conservationScore: 0.88,
          pathogenicity: "Pathogenic",
          confidence: 89.2,
          riskLevel: "High",
          clinicalInterpretation: "Von Hippel-Lindau tumor suppressor p.R161Q substitution. Frequently matched with VHL degradation pathway cancers and renal cell carcinomas."
        },
        {
          id: "chr10:g.43612032A>G",
          gene: "RET",
          chromosome: "Chr10",
          position: 43612032,
          refAllele: "A",
          altAllele: "G",
          consequence: "Missense",
          caddScore: 29.5,
          polyphenScore: 0.97,
          siftScore: 0.01,
          alleleFrequency: 0.000002,
          revelScore: 0.94,
          conservationScore: 0.94,
          pathogenicity: "Pathogenic",
          confidence: 96.1,
          riskLevel: "High",
          clinicalInterpretation: "Proto-oncogene RET RET p.C634R activates extracellular signaling independent of ligands. Directly correlated with Multiple Endocrine Neoplasia type 2."
        }
      ];

      setVariantsList(prev => [...uploadedMockVariantsList, ...prev]);
      
      const newJob: PredictionJob = {
        id: `JOB-${Math.random().toString(36).substr(2, 5).toUpperCase()}`,
        name: `Uploaded FASTA/VCF Lab Sequence - Panel_Run_VCF`,
        date: new Date().toLocaleString(),
        variantCount: uploadedMockVariantsList.length,
        status: "Completed",
        modelUsed: activeModel,
        results: uploadedMockVariantsList
      };
      setJobsList(prev => [newJob, ...prev]);

      setUploadStatus("done");
      triggerToast("Parsed sequence. 2 novel candidate oncology targets added.", "success");
      setTimeout(() => setUploadStatus(null), 3000);
    }, 1500);
  };

  const modelMetricsActual = defaultModelMetrics[activeModel] || defaultModelMetrics["OncoSage-XGBoost Neural V3"];

  // Filtered variants list representation
  const filteredVariants = variantsList.filter((v) => {
    const matchesSearch = v.gene.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          v.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesConsequence = consequenceFilter === "ALL" || v.consequence === consequenceFilter;
    const matchesRisk = riskFilter === "ALL" || v.riskLevel === riskFilter;
    return matchesSearch && matchesConsequence && matchesRisk;
  });

  // Handle Download clinical report or predictions
  const triggerPredictionDownload = () => {
    const headers = "Variant_ID,Gene,Chromosome,Position,Ref_Allele,Alt_Allele,Consequence,CADD,REVEL,PolyPhen2,SIFT,GnomAD_AF,Pathogenicity,Confidence_Pct,Risk_Level";
    const dataRows = variantsList.map(v => 
      `"${v.id}","${v.gene}","${v.chromosome}",${v.position},"${v.refAllele}","${v.altAllele}","${v.consequence}",${v.caddScore},${v.revelScore},${v.polyphenScore},${v.siftScore},${v.alleleFrequency},"${v.pathogenicity}",${v.confidence},"${v.riskLevel}"`
    ).join("\n");
    const contents = `${headers}\n${dataRows}`;
    const blob = new Blob([contents], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `OncoSageAI_Variant_Predictions_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    triggerToast("Prediction matrix catalog exported.", "success");
  };

  const triggerDiagnosticReportDownload = () => {
    const reportText = `========================================================================
ONCOSAGE AI - PATHOGENIC VARIANT CLINICAL CERTIFICATE
Report generated on: ${new Date().toISOString()}
Clinical Investigator: ${userProfile.name}
Institution: ${userProfile.institution}
========================================================================

PRIMARY VARIANT ANALYSIS DETAILS:
---------------------------------
Variant ID:      ${activeVariant.id}
Gene Target:     ${activeVariant.id.split(':')[0]} (${activeVariant.gene})
Locus:           ${activeVariant.chromosome} Position: ${activeVariant.position}
Substitution:    ${activeVariant.refAllele} > ${activeVariant.altAllele}
Consequence:     ${activeVariant.consequence}

MACHINE LEARNING PATHOLOGY ASSESSMENT:
--------------------------------------
Empirical Model: ${activeModel}
Pathogenicity:  ${activeVariant.pathogenicity?.toUpperCase()}
Confidence:     ${activeVariant.confidence}%
Risk Assessment: ${activeVariant.riskLevel?.toUpperCase()}

QUANTITATIVE CRITERIA METRICS:
------------------------------
CADD Genomic Deleteriousness:  ${activeVariant.caddScore} / 40
REVEL Rare Exome score:         ${activeVariant.revelScore}
PolyPhen-2 Protein Impact:      ${activeVariant.polyphenScore}
SIFT Residue Tolerability:       ${activeVariant.siftScore}
gnomAD Background Allele Freq:  ${activeVariant.alleleFrequency}
GERP++ Phylogenetic Conservation: ${activeVariant.conservationScore}

CLINICAL ONCOLOGY PATHOLOGIST SUMMARY:
-------------------------------------
${activeVariant.clinicalInterpretation}

DISCLAIMER: For research use only. Not for standalone clinical diagnosis.
========================================================================`;
    
    const blob = new Blob([reportText], { type: "text/plain;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `OncoSage_Clinical_Report_${activeVariant.gene}_${Date.now()}.txt`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    triggerToast(`Clinical report for ${activeVariant.gene} downloaded.`, "success");
    setShowExportModal(false);
  };

  return (
    <div className={`min-h-screen text-slate-200 transition-colors duration-300 font-sans ${isLightMode ? "bg-slate-50 text-slate-900" : "bg-[#020617]"}`}>
      {/* Abstract Glowing Background Orbs */}
      <div className="fixed top-[-10%] right-[-10%] w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-[140px] pointer-events-none animate-pulse-glow"></div>
      <div className="fixed bottom-[-5%] left-[-5%] w-[400px] h-[400px] bg-purple-600/10 rounded-full blur-[140px] pointer-events-none animate-pulse-glow" style={{ animationDelay: '3s' }}></div>

      {/* Dynamic Toast and notifications */}
      {toast && (
        <div className="fixed bottom-8 right-8 z-[100] max-w-sm px-6 py-4 rounded-xl border border-white/10 backdrop-blur-2xl shadow-[0_0_30px_rgba(0,192,255,0.25)] flex items-center gap-3 transition-all transform scale-100 bg-black/80">
          <Sparkles className="w-5 h-5 text-cyan-400 shrink-0" />
          <div className="text-xs font-mono font-medium tracking-tight text-white">{toast.message}</div>
        </div>
      )}

      {/* ==================== 1. LANDING PAGE SCREEN ==================== */}
      {!showWorkstation ? (
        <div id="landing-page-root" className="relative z-10 flex flex-col min-h-screen">
          {/* Landing Top Header */}
          <header className="max-w-7xl mx-auto w-full px-6 py-6 flex justify-between items-center bg-transparent">
            <div className="flex items-center gap-3 cursor-pointer">
              <div className="w-10 h-10 bg-gradient-to-tr from-cyan-400 via-transparent to-purple-600 rounded-xl flex items-center justify-center border border-white/15 drop-shadow-[0_0_15px_rgba(0,240,255,0.3)]">
                <Dna className="w-6 h-6 text-cyan-400" />
              </div>
              <div>
                <span className="text-xl font-black text-white tracking-widest uppercase">
                  OncoSage<span className="text-cyan-400 font-bold ml-1 text-sm bg-cyan-900/40 px-2 py-0.5 rounded border border-cyan-500/30">AI</span>
                </span>
                <p className="text-[9px] text-slate-500 font-semibold tracking-wider uppercase">Precision Medicine Research Core</p>
              </div>
            </div>

            <div className="flex items-center gap-6">
              <nav className="hidden md:flex gap-8">
                <a href="#features" className="text-xs font-mono uppercase text-slate-400 hover:text-cyan-400 transition-colors">Features</a>
                <a href="#pipeline" className="text-xs font-mono uppercase text-slate-400 hover:text-cyan-400 transition-colors">ML Architecture</a>
                <a href="#impact" className="text-xs font-mono uppercase text-slate-400 hover:text-cyan-400 transition-colors">Impact & Biof</a>
              </nav>
              <button 
                onClick={() => setShowWorkstation(true)}
                className="bg-cyan-500 hover:bg-cyan-400 text-black font-semibold tracking-wider font-mono px-5 py-2.5 rounded-lg text-xs leading-none transition-all duration-300 shadow-[0_0_20px_rgba(34,211,238,0.4)]"
              >
                ACCESS WORKSTATION
              </button>
            </div>
          </header>

          {/* Interactive Floating Hero Section */}
          <section className="flex-1 max-w-7xl mx-auto w-full px-6 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center pt-8 pb-16">
            <div className="lg:col-span-7 space-y-6">
              <span className="inline-flex items-center gap-2 px-3 py-1.5 bg-cyan-900/30 border border-cyan-500/30 rounded-full text-[10px] text-cyan-300 font-mono font-medium uppercase tracking-widest shadow-inner">
                <span className="flex h-1.5 w-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
                GENOMIC PATHOGENICITY ENGINE V2.4
              </span>

              <h1 className="text-4xl md:text-6xl font-extrabold text-white tracking-tight leading-none">
                AI-Powered Precision <br />
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-sky-300 to-purple-500 drop-shadow-sm">
                  Oncology Platform
                </span>
              </h1>

              <p className="text-sm md:text-base text-slate-400 leading-relaxed max-w-xl">
                OncoSage AI merges deep learning pipeline networks with molecular biology metrics to automate rare tumor variant classification, predict clinical mutated pathogenesis, and construct explainable targeted oncology therapies.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <button 
                  onClick={() => {
                    setShowWorkstation(true);
                    setActiveTab("analysis");
                  }} 
                  className="bg-gradient-to-r from-cyan-500 to-sky-500 hover:from-cyan-400 hover:to-sky-400 text-black font-bold uppercase tracking-wider text-xs px-8 py-4 rounded-xl shadow-[0_0_30px_rgba(0,240,255,0.3)] transition-all flex items-center justify-center gap-3"
                >
                  <Activity className="w-4 h-4" />
                  Predict Pathogenicity
                </button>
                <button 
                  onClick={() => setShowWorkstation(true)}
                  className="bg-white/5 hover:bg-white/10 text-white border border-white/10 font-bold uppercase tracking-wider text-xs px-8 py-4 rounded-xl transition-all flex items-center justify-center gap-2 backdrop-blur-md"
                >
                  Explore Dashboard
                  <ChevronRight className="w-4 h-4 text-cyan-400" />
                </button>
              </div>

              {/* Multi-feature list indicators */}
              <div className="grid grid-cols-3 gap-6 pt-8 border-t border-white/5">
                <div>
                  <div className="text-2xl font-black text-white font-mono">96.5%</div>
                  <div className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mt-1">XGBoost Accuracy</div>
                </div>
                <div>
                  <div className="text-2xl font-black text-cyan-400 font-mono">&lt; 3.2s</div>
                  <div className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mt-1">Prediction Speed</div>
                </div>
                <div>
                  <div className="text-2xl font-black text-purple-400 font-mono">24k+</div>
                  <div className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold mt-1">Somatic Databases</div>
                </div>
              </div>
            </div>

            {/* Immersive 3D DNA Canvas Widget */}
            <div className="lg:col-span-5 h-[320px] md:h-[450px] bg-white/[0.02] border border-white/10 rounded-3xl p-6 backdrop-blur-xl flex flex-col justify-between relative overflow-hidden group shadow-[0_0_50px_rgba(0,240,255,0.05)]">
              <div className="flex justify-between items-start z-20">
                <div>
                  <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-widest block">Double Helix Locus Model</span>
                  <span className="text-sm font-semibold text-slate-200 mt-1">JAK2/TP53 Struct Matrix</span>
                </div>
                <div className="p-2 rounded-lg bg-black/40 border border-white/10">
                  <Maximize2 className="w-4 h-4 text-slate-400 group-hover:text-cyan-400 transition-colors" />
                </div>
              </div>

              {/* Dynamic canvas DNA element */}
              <div className="absolute inset-0 z-10 py-16">
                <DnaHelix colorPrimary="#00f0ff" colorSecondary="#b026ff" speed={0.006} density={0.55} />
              </div>

              {/* Overlay Hologram stats box */}
              <div className="bg-black/80 border border-cyan-500/30 rounded-2xl p-4 backdrop-blur-xl z-20 transform hover:-translate-y-1 transition-all duration-300">
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                  <span className="text-[9px] font-mono tracking-widest font-bold text-cyan-400 uppercase">Live Spatial Mutagenesis</span>
                </div>
                <p className="text-[11px] leading-snug text-slate-300 font-mono">
                  Variant position <span className="text-white underline">chr17:7577120</span> triggers structural residue misalignment with SIFT probability &lt; 0.01.
                </p>
              </div>
            </div>
          </section>

          {/* Feature Grid Section */}
          <section id="features" className="bg-[#020617]/80 border-t border-white/5 py-16 z-20 relative">
            <div className="max-w-7xl mx-auto px-6">
              <div className="text-center max-w-xl mx-auto space-y-3 mb-12">
                <span className="text-xs font-mono text-purple-400 uppercase font-bold tracking-widest">ADVANCED PIPELINE DESIGN</span>
                <h2 className="text-3xl font-bold text-white tracking-tight">Harness the AI Precision Advantage</h2>
                <p className="text-xs text-slate-400">Our machine learning pipeline integrates evolutionary, clinical, and structural annotations to provide clinical-ready oncology metrics.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Feature Card 1 */}
                <div className="bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 hover:border-cyan-500/30 p-6 rounded-2xl transition-all duration-300 space-y-4">
                  <div className="w-12 h-12 rounded-xl bg-cyan-400/10 flex items-center justify-center text-cyan-400">
                    <Cpu className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-semibold text-white">AI Pathogenicity Predictors</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Uses multi-model ensemble classifiers (Random Forest, XGBoost and Neural models) to project Benign and Pathogenic clinical scores with high precision.
                  </p>
                </div>

                {/* Feature Card 2 */}
                <div className="bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 hover:border-purple-500/30 p-6 rounded-2xl transition-all duration-300 space-y-4">
                  <div className="w-12 h-12 rounded-xl bg-purple-400/10 flex items-center justify-center text-purple-400">
                    <Layers className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-semibold text-white">Chromosomal Spectrometers</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Interactive genomics visualizers including density heatmaps, sub-population frequency curves, ROC curves, and confusion model metrics.
                  </p>
                </div>

                {/* Feature Card 3 */}
                <div className="bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 hover:border-cyan-500/30 p-6 rounded-2xl transition-all duration-300 space-y-4">
                  <div className="w-12 h-12 rounded-xl bg-sky-400/10 flex items-center justify-center text-sky-400">
                    <Sparkles className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-semibold text-white">Explainable AI Annotations</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Provides true mathematical feature importance rankings and clinical reports, supported by LLM pathobiological translations on genomic parameters.
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Research Impact Statistics Banner */}
          <section id="impact" className="border-t border-white/5 py-12 bg-black/20 text-center relative overflow-hidden">
            <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8">
              <div>
                <div className="text-4xl font-extrabold text-white">99.1%</div>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mt-2">Area Under ROC (AUC)</p>
              </div>
              <div>
                <div className="text-4xl font-extrabold text-cyan-400">14,802</div>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mt-2">Tumors DNA Mapped</p>
              </div>
              <div>
                <div className="text-4xl font-extrabold text-purple-400">30+</div>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mt-2">Precision Genes Calibrated</p>
              </div>
              <div>
                <div className="text-4xl font-extrabold text-emerald-400">FDA-Matched</div>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mt-2">Therapeutics Protocols</p>
              </div>
            </div>
          </section>

          {/* Landing Footer */}
          <footer className="mt-auto border-t border-white/5 py-8 text-center text-xs text-slate-500 bg-black/40">
            <p className="font-mono uppercase tracking-widest text-[9px]">&copy; 2026 ONCOSAGE PRECISION HEALTHCARE LABS. ALL REPRINTS AND PATIENTS DECLASSIFIED RIGHTS RESERVED.</p>
          </footer>
        </div>
      ) : (
        /* ==================== 2. WORKSTATION CORE SCREEN ==================== */
        <div id="workstation-root" className="flex h-screen overflow-hidden text-slate-200">
          
          {/* LEFT COMPACT SIDEBAR NAVIGATION (Frosted, custom-styled) */}
          <aside className="w-18 md:w-20 flex flex-col items-center py-6 gap-8 border-r border-white/10 bg-black/40 backdrop-blur-xl z-20">
            {/* Launching Badge */}
            <div 
              onClick={() => setShowWorkstation(false)}
              className="w-10 h-10 bg-gradient-to-tr from-cyan-400 to-purple-600 rounded-xl flex items-center justify-center cursor-pointer shadow-[0_0_15px_rgba(0,240,255,0.4)] hover:scale-105 transition-all"
              title="Return to Splash Page"
            >
              <Dna className="w-5 h-5 text-white animate-pulse" />
            </div>

            {/* Navigation Options list */}
            <nav className="flex flex-col gap-5 flex-1 w-full px-2" id="workspace-sidebar-navigation">
              <button
                onClick={() => setActiveTab("dashboard")}
                className={`py-3 w-full rounded-xl flex flex-col items-center gap-1 transition-all ${
                  activeTab === "dashboard"
                    ? "bg-gradient-to-b from-cyan-950/50 to-cyan-900/10 border-l-2 border-cyan-400 text-cyan-300"
                    : "text-slate-400 hover:text-white"
                }`}
                title="Overview Dashboard"
              >
                <Activity className="w-5 h-5" />
                <span className="text-[8px] tracking-wide font-semibold uppercase pointer-events-none">Overview</span>
              </button>

              <button
                onClick={() => setActiveTab("analysis")}
                className={`py-3 w-full rounded-xl flex flex-col items-center gap-1 transition-all ${
                  activeTab === "analysis"
                    ? "bg-gradient-to-b from-cyan-950/50 to-cyan-900/10 border-l-2 border-cyan-400 text-cyan-300"
                    : "text-slate-400 hover:text-white"
                }`}
                title="Somatic Filter Engine"
              >
                <Filter className="w-5 h-5" />
                <span className="text-[8px] tracking-wide font-semibold uppercase pointer-events-none">Filter</span>
              </button>

              <button
                onClick={() => setActiveTab("visualizer")}
                className={`py-3 w-full rounded-xl flex flex-col items-center gap-1 transition-all ${
                  activeTab === "visualizer"
                    ? "bg-gradient-to-b from-cyan-950/50 to-cyan-900/10 border-l-2 border-cyan-400 text-cyan-300"
                    : "text-slate-400 hover:text-white"
                }`}
                title="Visual Spectrometer"
              >
                <Layers className="w-5 h-5" />
                <span className="text-[8px] tracking-wide font-semibold uppercase pointer-events-none">Visual</span>
              </button>

              <button
                onClick={() => setActiveTab("insights")}
                className={`py-3 w-full rounded-xl flex flex-col items-center gap-1 transition-all ${
                  activeTab === "insights"
                    ? "bg-gradient-to-b from-cyan-950/50 to-cyan-900/10 border-l-2 border-cyan-400 text-cyan-300"
                    : "text-slate-400 hover:text-white"
                }`}
                title="Feature & SHAP Analytics"
              >
                <TrendingUp className="w-5 h-5" />
                <span className="text-[8px] tracking-wide font-semibold uppercase pointer-events-none">Insights</span>
              </button>

              <button
                onClick={() => setActiveTab("history")}
                className={`py-3 w-full rounded-xl flex flex-col items-center gap-1 transition-all ${
                  activeTab === "history"
                    ? "bg-gradient-to-b from-cyan-950/50 to-cyan-900/10 border-l-2 border-cyan-400 text-cyan-300"
                    : "text-slate-400 hover:text-white"
                }`}
                title="Model History Logs"
              >
                <History className="w-5 h-5" />
                <span className="text-[8px] tracking-wide font-semibold uppercase pointer-events-none">History</span>
              </button>

              <button
                onClick={() => setActiveTab("assistant")}
                className={`py-3 w-full rounded-xl flex flex-col items-center gap-1 transition-all ${
                  activeTab === "assistant"
                    ? "bg-gradient-to-b from-cyan-950/50 to-cyan-900/10 border-l-2 border-cyan-400 text-cyan-300"
                    : "text-slate-400 hover:text-white"
                }`}
                title="AI Research Assistant Chat"
              >
                <MessageSquare className="w-5 h-5 animate-pulse" />
                <span className="text-[8px] tracking-wide font-semibold uppercase pointer-events-none">Chat</span>
              </button>

              <button
                onClick={() => setActiveTab("settings")}
                className={`py-3 w-full rounded-xl flex flex-col items-center gap-1 transition-all ${
                  activeTab === "settings"
                    ? "bg-gradient-to-b from-cyan-950/50 to-cyan-900/10 border-l-2 border-cyan-400 text-cyan-300"
                    : "text-slate-400 hover:text-white"
                }`}
                title="Neural Configuration Settings"
              >
                <Settings className="w-5 h-5" />
                <span className="text-[8px] tracking-wide font-semibold uppercase pointer-events-none">Configure</span>
              </button>
            </nav>

            {/* Profile badge */}
            <div className="pt-4 border-t border-white/5 w-full flex justify-center">
              <div 
                className="w-10 h-10 rounded-full border border-cyan-500/30 overflow-hidden cursor-pointer hover:border-cyan-400 transition-all shadow-[0_0_10px_rgba(34,211,238,0.2)]"
                title={`${userProfile.name} - ${userProfile.role}`}
                onClick={() => setActiveTab("settings")}
              >
                <img src={userProfile.avatar} alt="Doctor Vance" className="w-full h-full object-cover" />
              </div>
            </div>
          </aside>

          {/* RIGHT VIEW COMPONENT CONTAINER */}
          <main className="flex-1 flex flex-col min-w-0 overflow-y-auto relative h-screen">
            
            {/* Top Workspace Header (Glassmorphic Top Bar) */}
            <header className="px-6 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-black/20 border-b border-white/10 backdrop-blur-xl sticky top-0 z-40">
              <div>
                <div className="flex items-center gap-3">
                  <h2 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400 tracking-tight">
                    OncoSage <span className="text-cyan-400">AI Workstation</span>
                  </h2>
                  <span className="text-[10px] bg-purple-500/10 border border-purple-500/20 text-purple-400 font-mono px-2 py-0.5 rounded uppercase">
                    Model: {activeModel}
                  </span>
                </div>
                <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold mt-1">
                  Molecular Pathology & Deep Variants Scoring Suite • Beta v2.4
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                {/* Real-time simulation state widget */}
                <div className="px-3.5 py-1.5 bg-white/5 border border-white/10 rounded-lg flex items-center gap-2">
                  <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span className="text-[10px] font-mono text-slate-400 uppercase">Engine Status: Continuous Prediction</span>
                </div>

                <button 
                  onClick={() => setShowAddVariantModal(true)}
                  className="bg-cyan-500 hover:bg-cyan-400 text-black font-semibold text-xs font-mono px-4 py-2 rounded-lg shadow-[0_0_15px_rgba(0,240,255,0.30)] transition-all uppercase"
                >
                  New Analysis Variant
                </button>
              </div>
            </header>

            {/* SCROLLABLE VIEW GRID DYNAMIC RENDERING BLOCK */}
            <div className="flex-1 p-6 relative">
              
              {/* ==================== SUB-PAGE 1: OVERVIEW DASHBOARD ==================== */}
              {activeTab === "dashboard" && (
                <div className="space-y-6 animate-fade-in">
                  
                  {/* Summary Metric Strip */}
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    {/* Stat Card 1 */}
                    <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl">
                      <div className="flex justify-between items-start text-slate-400">
                        <span className="text-[10px] font-mono uppercase tracking-widest">Somatic Mutations Cataloged</span>
                        <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400">
                          <Database className="w-4 h-4" />
                        </div>
                      </div>
                      <div className="text-3xl font-extrabold text-white font-mono mt-3">{variantsList.length}</div>
                      <div className="text-[10px] text-green-400 font-mono mt-2 flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" />
                        <span>Continuous update active</span>
                      </div>
                    </div>

                    {/* Stat Card 2 */}
                    <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl">
                      <div className="flex justify-between items-start text-slate-400">
                        <span className="text-[10px] font-mono uppercase tracking-widest">Predictive Precision (F1)</span>
                        <div className="p-2 rounded-lg bg-pink-500/10 text-pink-400">
                          <Activity className="w-4 h-4" />
                        </div>
                      </div>
                      <div className="text-3xl font-extrabold text-white font-mono mt-3">
                        {Math.round(modelMetricsActual.f1Score * 1000) / 1000}
                      </div>
                      <div className="text-[10px] text-cyan-400 font-mono mt-2">
                        <span>Current model evaluation</span>
                      </div>
                    </div>

                    {/* Stat Card 3 */}
                    <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl">
                      <div className="flex justify-between items-start text-slate-400">
                        <span className="text-[10px] font-mono uppercase tracking-widest">Highly Pathogenic Rate</span>
                        <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
                          <Flame className="w-4 h-4" />
                        </div>
                      </div>
                      <div className="text-3xl font-extrabold text-white font-mono mt-3">{pathogenicRatio}%</div>
                      <div className="text-[10px] text-amber-400 font-mono mt-2">
                        <span>Proportion exceeding threshold {thresholdValue}</span>
                      </div>
                    </div>

                    {/* Stat Card 4 */}
                    <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl">
                      <div className="flex justify-between items-start text-slate-400">
                        <span className="text-[10px] font-mono uppercase tracking-widest">Critical Variant Alerts</span>
                        <div className="p-2 rounded-lg bg-red-500/10 text-red-500">
                          <AlertTriangle className="w-4 h-4" />
                        </div>
                      </div>
                      <div className="text-3xl font-extrabold text-red-400 font-mono mt-3">{criticalCount}</div>
                      <div className="text-[10px] text-red-400/80 font-mono mt-2">
                        <span>High / Critical patient risks list</span>
                      </div>
                    </div>
                  </div>

                  {/* Primary interactive dashboard layout */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    
                    {/* BENTO BOX 1: Genomic Helix spectrum & hotpot visualizer */}
                    <div className="lg:col-span-8 bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl space-y-4">
                      <div className="flex justify-between items-center pb-2 border-b border-white/5">
                        <div>
                          <h3 className="text-sm font-bold text-white uppercase tracking-wider">Mutational Locus Chromosome Map</h3>
                          <p className="text-[11px] text-slate-400">Heatmap representation of high-pathogenicity hot spots mapped on sequence coordinates</p>
                        </div>
                        <span className="text-[10px] font-mono bg-cyan-500/10 text-cyan-400 px-2 py-1 rounded">Interactive Spectrum</span>
                      </div>

                      {/* Custom genomic heat spectrum layout */}
                      <div className="space-y-6 pt-2">
                        <div className="h-28 w-full flex items-end gap-1 px-4 py-2 bg-black/30 rounded-xl relative overflow-hidden border border-white/5">
                          {variantsList.map((v, i) => {
                            const percentHeight = Math.min(100, Math.max(10, v.caddScore * 2.5));
                            const isSelected = v.id === selectedVariantId;
                            const isPathogenic = v.pathogenicity === "Pathogenic";
                            const barColorClass = isPathogenic 
                              ? "bg-gradient-to-t from-red-600 via-rose-500 to-rose-400 shadow-[0_0_10px_rgba(244,63,94,0.3)]" 
                              : v.pathogenicity === "VUS"
                                ? "bg-gradient-to-t from-amber-600 to-amber-400"
                                : "bg-gradient-to-t from-cyan-600 to-sky-400";
                            return (
                              <div 
                                key={v.id}
                                className={`flex-1 group cursor-pointer transition-all ${isSelected ? 'ring-2 ring-cyan-400 scale-102 z-10' : 'hover:opacity-100 opacity-80'}`}
                                style={{ height: `${percentHeight}%` }}
                                onClick={() => setSelectedVariantId(v.id)}
                              >
                                <div className={`w-full h-full rounded-sm ${barColorClass}`} />
                                {/* Absolute helper coordinate box on hover */}
                                <div className="absolute hidden group-hover:block bottom-16 left-1/2 transform -translate-x-1/2 bg-slate-900 border border-white/15 px-3 py-2 rounded-lg text-[10px] w-48 text-left backdrop-blur-2xl text-slate-100 z-50 shadow-2xl">
                                  <div className="font-bold text-cyan-300">{v.gene} • {v.id.split(':')[1]}</div>
                                  <div className="text-[9px] text-slate-400 mt-1">CADD score: {v.caddScore} ({v.pathogenicity})</div>
                                  <div className="text-[9px] text-slate-400">Freq: {v.alleleFrequency}</div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                        <div className="flex justify-between text-[11px] font-mono text-slate-500 px-4">
                          <span>Chr3:10.18M</span>
                          <span>Chr7:55.24M</span>
                          <span>Chr10:89.69M</span>
                          <span>Chr12:25.39M</span>
                          <span>Chr17:7.57M</span>
                        </div>
                      </div>

                      {/* Selected genomic variant pathologist analysis report card */}
                      <div className="bg-black/40 border border-cyan-500/25 rounded-xl p-4 space-y-3 relative">
                        <div className="absolute top-4 right-4 flex items-center gap-2">
                          <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                            activeVariant.pathogenicity === "Pathogenic" ? "bg-rose-500/20 text-rose-400 border border-rose-500/30" :
                            activeVariant.pathogenicity === "VUS" ? "bg-amber-500/20 text-amber-400 border border-amber-500/30" :
                            "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                          }`}>
                            {activeVariant.pathogenicity} ({activeVariant.confidence}% conf)
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <Flame className="w-4.5 h-4.5 text-cyan-400 animate-pulse" />
                          <h4 className="text-xs font-bold uppercase tracking-wider text-white">Active Diagnostic Target: {activeVariant.gene}</h4>
                        </div>
                        
                        <p className="text-xs text-slate-300 leading-relaxed italic">
                          "{activeVariant.clinicalInterpretation || 'Molecular signature represents highly localized chromosome genomic variance requiring continuous screening predictions.'}"
                        </p>

                        <div className="flex justify-between items-center text-[11px] font-mono text-slate-400 border-t border-white/5 pt-2">
                          <span>Consequence: {activeVariant.consequence}</span>
                          <span>CADD: {activeVariant.caddScore}</span>
                          <button 
                            onClick={() => {
                              setSelectedVariantId(activeVariant.id);
                              setActiveTab("insights");
                            }}
                            className="text-cyan-400 hover:underline flex items-center gap-1"
                          >
                            Explainable AI reasoning <ArrowRight className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                    </div>

                    {/* BENTO BOX 2: Neural Calibration controls */}
                    <div className="lg:col-span-4 bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl flex flex-col justify-between space-y-4">
                      
                      <div>
                        <h3 className="text-sm font-bold text-white uppercase tracking-wider pb-2 border-b border-white/5">
                          Threshold & Weights
                        </h3>
                        <p className="text-xs text-slate-400 mt-2">
                          Recalibrate confidence thresholds and diagnostic weights used in Random Forest & XGBoost modeling pipelines.
                        </p>
                      </div>

                      {/* Threshold Slider */}
                      <div className="space-y-2 py-2">
                        <div className="flex justify-between text-xs font-mono">
                          <span className="text-slate-400">Pathogenic Threshold score</span>
                          <span className="text-cyan-400 font-bold">{thresholdValue}</span>
                        </div>
                        <input 
                          type="range" 
                          min="0.30" 
                          max="0.90" 
                          step="0.05" 
                          value={thresholdValue} 
                          onChange={(e) => setThresholdValue(Number(e.target.value))}
                          className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                        />
                        <div className="flex justify-between text-[9px] font-mono text-slate-500">
                          <span>0.30 (Sensitive)</span>
                          <span>0.90 (Specific)</span>
                        </div>
                      </div>

                      {/* Weight distribution stack */}
                      <div className="space-y-3">
                        <span className="text-[10px] font-mono uppercase tracking-widest text-purple-400 font-bold block">Pipeline Weight Variables</span>
                        
                        {/* Weight REVEL */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-[11px] font-mono text-slate-400">
                            <span>REVEL ensemble</span>
                            <span>{Math.round(userSettings.revelWeight * 100)}%</span>
                          </div>
                          <div className="w-full bg-slate-800 h-1 rounded-full">
                            <div className="bg-gradient-to-r from-cyan-400 to-teal-400 h-full rounded-full" style={{ width: `${userSettings.revelWeight * 100}%` }}></div>
                          </div>
                        </div>

                        {/* Weight CADD */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-[11px] font-mono text-slate-400">
                            <span>CADD deleterious</span>
                            <span>{Math.round(userSettings.caddWeight * 100)}%</span>
                          </div>
                          <div className="w-full bg-slate-800 h-1 rounded-full">
                            <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-full rounded-full" style={{ width: `${userSettings.caddWeight * 100}%` }}></div>
                          </div>
                        </div>

                        {/* Weight gnomAD */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-[11px] font-mono text-slate-400">
                            <span>gnomAD Population Freq</span>
                            <span>{Math.round(userSettings.gnomadWeight * 100)}%</span>
                          </div>
                          <div className="w-full bg-slate-800 h-1 rounded-full">
                            <div className="bg-amber-500 h-full rounded-full" style={{ width: `${userSettings.gnomadWeight * 100}%` }}></div>
                          </div>
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* Active Variants table quick snapshot */}
                  <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-sm font-bold text-white uppercase tracking-wider">Candidate Tumor Mutations</h3>
                      <button 
                        onClick={() => setActiveTab("analysis")}
                        className="text-xs font-mono text-cyan-400 hover:underline flex items-center gap-1"
                      >
                        All Filters <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-white/10 text-[10px] uppercase font-mono text-slate-400">
                            <th className="py-3 px-2">Gene</th>
                            <th className="py-3 px-2">Variant coordinates</th>
                            <th className="py-3 px-2">Consequence</th>
                            <th className="py-3 px-2">CADD score</th>
                            <th className="py-3 px-2">REVEL</th>
                            <th className="py-3 px-2">Sub-Pop Freq</th>
                            <th className="py-3 px-2">Pathogenicity</th>
                            <th className="py-3 px-2">Classification</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5 text-xs">
                          {variantsList.slice(0, 5).map((v) => (
                            <tr 
                              key={v.id} 
                              onClick={() => setSelectedVariantId(v.id)}
                              className={`cursor-pointer transition-all hover:bg-white/[0.02] ${selectedVariantId === v.id ? 'bg-cyan-500/10' : ''}`}
                            >
                              <td className="py-3 px-2 font-bold text-white">{v.gene}</td>
                              <td className="py-3 px-2 font-mono text-slate-400">{v.id}</td>
                              <td className="py-3 px-2 text-slate-300">{v.consequence}</td>
                              <td className="py-3 px-2 font-mono text-slate-300">{v.caddScore}</td>
                              <td className="py-3 px-2 font-mono text-slate-300">{v.revelScore}</td>
                              <td className="py-3 px-2 font-mono text-slate-400">{v.alleleFrequency}</td>
                              <td className="py-3 px-2 font-bold">
                                <span className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                                  v.pathogenicity === 'Pathogenic' ? 'text-red-400 bg-red-400/10' :
                                  v.pathogenicity === 'VUS' ? 'text-amber-400 bg-amber-400/10' :
                                  'text-cyan-400 bg-cyan-400/10'
                                }`}>
                                  {v.pathogenicity}
                                </span>
                              </td>
                              <td className="py-3 px-2 text-slate-400">
                                <span className={`text-[10px] font-semibold uppercase ${
                                  v.riskLevel === 'Critical' ? 'text-red-500' :
                                  v.riskLevel === 'High' ? 'text-orange-400' :
                                  v.riskLevel === 'Medium' ? 'text-amber-400' : 'text-slate-400'
                                }`}>
                                  {v.riskLevel}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>
              )}

              {/* ==================== SUB-PAGE 2: VARIANT ANALYSIS PAGE ==================== */}
              {activeTab === "analysis" && (
                <div className="space-y-6 animate-fade-in">
                  
                  {/* Title and stats bar */}
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div>
                      <h3 className="text-lg font-bold text-white uppercase tracking-wider">Precision Variant Explorer</h3>
                      <p className="text-xs text-slate-400">Upload genetic variant panels (VCF, JSON), configure sorting, and filter high-risk candidates.</p>
                    </div>

                    <div className="flex items-center gap-3">
                      <button 
                        onClick={triggerPredictionDownload}
                        className="bg-white/5 hover:bg-white/10 text-white border border-white/10 font-mono text-xs px-4 py-2 rounded-lg transition-all flex items-center gap-2"
                        title="Download raw dataset values as CSV"
                      >
                        <Download className="w-4.5 h-4.5 text-cyan-400" />
                        Download CSV Dataset
                      </button>

                      <button 
                        onClick={() => setShowExportModal(true)}
                        className="bg-[#00f0ff]/10 hover:bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/30 font-mono text-xs px-4 py-2 rounded-lg transition-all flex items-center gap-2"
                        title="Export diagnostic patient assessment"
                      >
                        <FileText className="w-4.5 h-4.5" />
                        Export Diagnostic Report
                      </button>
                    </div>
                  </div>

                  {/* Drag and Drop Sequence uploading panel */}
                  <div 
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}
                    className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center transition-all cursor-pointer ${
                      isDragging 
                        ? "border-cyan-400 bg-cyan-500/10" 
                        : "border-white/10 bg-white/[0.01] hover:bg-white/[0.03]"
                    }`}
                  >
                    <UploadCloud className="w-12 h-12 text-cyan-400 animate-bounce mb-3" />
                    {uploadStatus === "analyzing" ? (
                      <div className="space-y-2">
                        <p className="text-sm font-bold text-cyan-400 uppercase tracking-widest animate-pulse">Running pipeline feature engineering scans...</p>
                        <p className="text-xs text-slate-400 italic">Formatting sequences coordinates, calibrating PolyPhen & CADD dimensions</p>
                      </div>
                    ) : uploadStatus === "done" ? (
                      <div className="space-y-2">
                        <p className="text-sm font-bold text-green-400 uppercase tracking-widest">Dataset alignment completed successfully!</p>
                        <p className="text-xs text-slate-400 italic">Added calculated variants to historical screening lists</p>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <p className="text-sm font-semibold text-white">Drag & drop clinical genomic panel files (VCF / TSV / CSV)</p>
                        <p className="text-xs text-slate-400">or click to browse local laboratory sequence files. Maximum upload threshold: 50MB</p>
                      </div>
                    )}
                  </div>

                  {/* Search, filters & tables panel */}
                  <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                      
                      {/* Search Gene/Locus */}
                      <div className="relative">
                        <Search className="absolute left-3 top-3.5 w-4 h-4 text-slate-400" />
                        <input 
                          type="text" 
                          placeholder="Search gene target (e.g. EGFR)..." 
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="w-full bg-black/40 border border-white/10 rounded-xl pl-9 pr-4 py-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors"
                        />
                      </div>

                      {/* Consequence Filter */}
                      <div className="relative">
                        <select 
                          value={consequenceFilter} 
                          onChange={(e) => setConsequenceFilter(e.target.value)}
                          className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-400 appearance-none cursor-pointer"
                        >
                          <option value="ALL">CONSEQUENCE TYPE: ALL</option>
                          <option value="Missense">Missense</option>
                          <option value="Nonsense">Nonsense</option>
                          <option value="Frameshift">Frameshift</option>
                          <option value="Synonymous">Synonymous</option>
                        </select>
                      </div>

                      {/* Risk filter */}
                      <div className="relative">
                        <select 
                          value={riskFilter} 
                          onChange={(e) => setRiskFilter(e.target.value)}
                          className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-400 appearance-none cursor-pointer"
                        >
                          <option value="ALL">RISK CLASSIFICATION: ALL</option>
                          <option value="Critical">Critical</option>
                          <option value="High">High</option>
                          <option value="Medium">Medium</option>
                          <option value="Low">Low</option>
                        </select>
                      </div>

                      {/* Model Selector switcher */}
                      <div className="relative">
                        <select 
                          value={activeModel} 
                          onChange={(e) => setActiveModel(e.target.value)}
                          className="w-full bg-cyan-950/20 border border-cyan-500/30 rounded-xl px-4 py-2.5 text-xs text-cyan-300 focus:outline-none focus:border-cyan-400 appearance-none cursor-pointer"
                        >
                          <option value="OncoSage-XGBoost Neural V3">XGBoost Neural V3</option>
                          <option value="OncoSage-RandomForest V2">Random Forest V2</option>
                          <option value="OncoSage-LogRegression V1">Logistic Regression V1</option>
                        </select>
                      </div>

                    </div>

                    {/* Filter result listing */}
                    <div className="overflow-x-auto text-slate-300">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-white/10 text-[10px] uppercase font-mono text-slate-400">
                            <th className="py-3 px-2">Gene</th>
                            <th className="py-3 px-2">Variant coordinates</th>
                            <th className="py-3 px-2">Consequence</th>
                            <th className="py-3 px-2">CADD score</th>
                            <th className="py-3 px-2">REVEL</th>
                            <th className="py-3 px-2">SIFT Tolerance</th>
                            <th className="py-3 px-2">gnomAD Population Freq</th>
                            <th className="py-3 px-2">State Verdict</th>
                            <th className="py-3 px-2">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5 text-xs">
                          {filteredVariants.map((v) => (
                            <tr 
                              key={v.id} 
                              className={`transition-all hover:bg-white/[0.02] cursor-pointer ${selectedVariantId === v.id ? 'bg-cyan-500/10' : ''}`}
                              onClick={() => setSelectedVariantId(v.id)}
                            >
                              <td className="py-3 px-2 font-bold text-white">{v.gene}</td>
                              <td className="py-3 px-2 font-mono text-slate-400">{v.id}</td>
                              <td className="py-3 px-2">{v.consequence}</td>
                              <td className="py-3 px-2 font-mono">{v.caddScore}</td>
                              <td className="py-3 px-2 font-mono">{v.revelScore}</td>
                              <td className={`py-3 px-2 font-mono ${v.siftScore <= 0.05 ? 'text-red-400 font-bold' : ''}`}>
                                {v.siftScore}
                              </td>
                              <td className="py-3 px-2 font-mono text-slate-400">{v.alleleFrequency}</td>
                              <td className="py-3 px-2">
                                <span className={`text-[10px] px-2.5 py-0.5 rounded font-mono font-bold ${
                                  v.pathogenicity === 'Pathogenic' ? 'text-red-400 bg-red-400/10 border border-red-500/20' :
                                  v.pathogenicity === 'VUS' ? 'text-amber-400 bg-amber-400/10 border border-amber-500/20' :
                                  'text-cyan-400 bg-cyan-400/10 border border-cyan-500/20'
                                }`}>
                                  {v.pathogenicity}
                                </span>
                              </td>
                              <td className="py-3 px-2">
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedVariantId(v.id);
                                    setActiveTab("insights");
                                  }}
                                  className="text-[10px] bg-white/5 border border-white/10 hover:border-cyan-500/30 text-white rounded px-2.5 py-1 transition-all uppercase"
                                >
                                  Reasoning
                                </button>
                              </td>
                            </tr>
                          ))}
                          {filteredVariants.length === 0 && (
                            <tr>
                              <td colSpan={9} className="py-12 text-center text-slate-500 italic">
                                No variants matched current search query or combination of risk filters. Try clearing constraints.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>
              )}

              {/* ==================== SUB-PAGE 3: VISUALIZATION PAGE ==================== */}
              {activeTab === "visualizer" && (
                <div className="space-y-6 animate-fade-in">
                  
                  <div>
                    <h3 className="text-lg font-bold text-white uppercase tracking-wider">Bioinformatic Visual Spectrometer</h3>
                    <p className="text-xs text-slate-400">Quantitative charts mapping genomic deleteriousness metrics against sub-population allele frequencies, alongside standard model metrics reports.</p>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    
                    {/* CHART 1: CADD Score deleterious scatterplot coordinate charts */}
                    <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl space-y-4">
                      <div>
                        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">SIFT/PolyPhen Residue Severity Scatter</h4>
                        <p className="text-[11px] text-slate-500">Lower SIFT combined with higher PolyPhen indicates extreme biological constraints</p>
                      </div>

                      {/* Custom SVG Scatter plot */}
                      <div className="h-64 px-4 relative flex items-center justify-center bg-black/40 rounded-xl border border-white/5">
                        <svg className="w-full h-full" viewBox="0 0 400 200">
                          {/* Grid Lines */}
                          <line x1="40" y1="20" x2="380" y2="20" stroke="rgba(255,255,255,0.05)" />
                          <line x1="40" y1="70" x2="380" y2="70" stroke="rgba(255,255,255,0.05)" />
                          <line x1="40" y1="120" x2="380" y2="120" stroke="rgba(255,255,255,0.05)" />
                          <line x1="40" y1="170" x2="380" y2="170" stroke="rgba(255,255,255,0.1)" />
                          <line x1="40" y1="20" x2="40" y2="170" stroke="rgba(255,255,255,0.1)" />

                          {/* Axis labels */}
                          <text x="5" y="100" fill="gray" fontSize="9" transform="rotate(-90 15 100)" textAnchor="middle">PolyPhen-2 Score</text>
                          <text x="210" y="195" fill="gray" fontSize="9" textAnchor="middle">SIFT Residue Score</text>

                          {/* Scatter items */}
                          {variantsList.map((v, i) => {
                            // Map SIFT (0 to 1) to X coordinate (40 to 380)
                            const x = 40 + (v.siftScore * 340);
                            // Map PolyPhen-2 (0 to 1) to Y coordinate (170 to 20)
                            const y = 170 - (v.polyphenScore * 150);
                            const isSelected = v.id === selectedVariantId;
                            const isPathogenic = v.pathogenicity === "Pathogenic";
                            const dotColor = isPathogenic ? "#f43f5e" : v.pathogenicity === "VUS" ? "#fbbf24" : "#00f0ff";
                            
                            return (
                              <g key={v.id} className="cursor-pointer" onClick={() => setSelectedVariantId(v.id)}>
                                <circle 
                                  cx={x} 
                                  cy={y} 
                                  r={isSelected ? 8 : 4.5} 
                                  fill={dotColor}
                                  stroke={isSelected ? "#ffffff" : "transparent"}
                                  strokeWidth={1.5}
                                  opacity={isSelected ? 1.0 : 0.75}
                                />
                                {isSelected && (
                                  <text x={x + 10} y={y - 5} fill="white" fontSize="9" className="font-bold">
                                    {v.gene}
                                  </text>
                                )}
                              </g>
                            );
                          })}
                        </svg>
                      </div>

                      <div className="flex justify-center gap-6 text-[10px] uppercase font-mono">
                        <div className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                          <span>Pathogenic</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
                          <span>VUS</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
                          <span>Benign</span>
                        </div>
                      </div>

                    </div>

                    {/* CHART 2: Model Performance ROC Curves */}
                    <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl space-y-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">ROC Classification Curve</h4>
                          <p className="text-[11px] text-slate-500">Model accuracy capabilities measuring true false ratios bounds</p>
                        </div>
                        <span className="text-[10px] font-mono text-cyan-400 bg-cyan-500/10 px-2.5 py-0.5 rounded font-bold">AUC: {modelMetricsActual.auc}</span>
                      </div>

                      <div className="h-64 relative flex items-center justify-center bg-black/40 rounded-xl border border-white/5">
                        <svg className="w-full h-full" viewBox="0 0 300 200">
                          {/* Grid boundaries */}
                          <rect x="30" y="20" width="240" height="150" fill="transparent" stroke="rgba(255,255,255,0.08)" />
                          {/* Random predictor baseline */}
                          <line x1="30" y1="170" x2="270" y2="20" stroke="gray" strokeWidth="1" strokeDasharray="3" />

                          {/* ROC Line */}
                          <polyline 
                            fill="none" 
                            stroke="#00f0ff" 
                            strokeWidth="3.5" 
                            points={modelMetricsActual.rocCurve.map(pt => {
                              // map FPR (0 to 1) to X (30 to 270)
                              const x = 30 + (pt.fpr * 240);
                              // map TPR (0 to 1) to Y (170 to 20)
                              const y = 170 - (pt.tpr * 150);
                              return `${x},${y}`;
                            }).join(" ")}
                            className="drop-shadow-[0_0_15px_rgba(0,192,255,0.5)]"
                          />

                          {/* Axes text */}
                          <text x="150" y="195" fill="gray" fontSize="9" textAnchor="middle">False Positive Rate (FPR)</text>
                          <text x="10" y="95" fill="gray" fontSize="9" transform="rotate(-90 10 95)" textAnchor="middle">True Positive Rate (TPR)</text>

                          {/* Key thresholds labels */}
                          <text x="210" y="50" fill="#00f0ff" fontSize="9" className="font-bold">Current Cutoff</text>
                        </svg>
                      </div>

                      <p className="text-[11px] text-slate-400 italic text-center">
                        Selected configuration parameters yielded validation ratios of **{modelMetricsActual.accuracy * 100}%** average precision.
                      </p>
                    </div>

                    {/* CHART 3: Confusion Matrix Layout */}
                    <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl space-y-4">
                      <div>
                        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Validation Confusion Matrix</h4>
                        <p className="text-[11px] text-slate-500">Breakdown of calculated positives vs negatives cohorts</p>
                      </div>

                      <div className="grid grid-cols-2 gap-3 pb-2 pt-2 text-center text-xs">
                        <div className="bg-cyan-500/10 p-4 border border-cyan-500/25 rounded-xl">
                          <div className="text-xs text-slate-400 font-mono">True Positives (TP)</div>
                          <div className="text-3xl font-black text-cyan-400 font-mono mt-1">{modelMetricsActual.confusionMatrix.truePositive}</div>
                        </div>

                        <div className="bg-purple-900/10 p-4 border border-purple-500/15 rounded-xl">
                          <div className="text-xs text-slate-400 font-mono">False Positives (FP)</div>
                          <div className="text-3xl font-black text-purple-400 font-mono mt-1">{modelMetricsActual.confusionMatrix.falsePositive}</div>
                        </div>

                        <div className="bg-purple-900/10 p-4 border border-purple-500/15 rounded-xl">
                          <div className="text-xs text-slate-400 font-mono">False Negatives (FN)</div>
                          <div className="text-3xl font-black text-purple-400 font-mono mt-1">{modelMetricsActual.confusionMatrix.falseNegative}</div>
                        </div>

                        <div className="bg-emerald-500/10 p-4 border border-emerald-500/25 rounded-xl">
                          <div className="text-xs text-slate-400 font-mono">True Negatives (TN)</div>
                          <div className="text-3xl font-black text-emerald-400 font-mono mt-1">{modelMetricsActual.confusionMatrix.trueNegative}</div>
                        </div>
                      </div>
                    </div>

                    {/* CHART 4: Mutation consequences spectrum chart */}
                    <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl flex flex-col justify-between space-y-4">
                      <div>
                        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Somatic Consequence Distribution</h4>
                        <p className="text-[11px] text-slate-500">Overview of consequences classifications across sequence cohort</p>
                      </div>

                      {/* Custom bar distribution rendering */}
                      <div className="space-y-3.5">
                        {/* Missense bar */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs text-slate-300">
                            <span>Missense Mutant Residues</span>
                            <span className="font-mono">7 Variants</span>
                          </div>
                          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                            <div className="bg-[#00f0ff] h-full" style={{ width: '70%' }}></div>
                          </div>
                        </div>

                        {/* Nonsense bar */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs text-slate-300">
                            <span>Nonsense stop-codons</span>
                            <span className="font-mono">2 Variants</span>
                          </div>
                          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                            <div className="bg-[#b026ff] h-full" style={{ width: '20%' }}></div>
                          </div>
                        </div>

                        {/* Synonymous bar */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs text-slate-300">
                            <span>Synonymous normal splice</span>
                            <span className="font-mono">1 Variant</span>
                          </div>
                          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                            <div className="bg-amber-400 h-full" style={{ width: '10%' }}></div>
                          </div>
                        </div>
                      </div>

                      <div className="bg-black/20 p-3 rounded-lg border border-white/5 text-[11px] text-slate-400 italic">
                        Highly aggressive mutations correspond to loss-of-function stop-gain (Nonsense) consequence structures.
                      </div>
                    </div>

                  </div>

                </div>
              )}

              {/* ==================== SUB-PAGE 4: EXPLAINABLE AI & SHAP INSIGHTS ==================== */}
              {activeTab === "insights" && (
                <div className="space-y-6 animate-fade-in">
                  
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div>
                      <h3 className="text-lg font-bold text-white uppercase tracking-wider">Explainable AI (SHAP) Module</h3>
                      <p className="text-xs text-slate-400">Visualize feature importance values representing mathematically what triggers risk predictions.</p>
                    </div>

                    <div className="px-3 py-1.5 bg-purple-500/10 border border-purple-500/20 text-purple-400 font-mono text-xs rounded uppercase flex items-center gap-2">
                      <Cpu className="w-4 h-4 animate-spin-slow" />
                      <span>Diagnostics: Shapley Value Spectrum</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    
                    {/* Feature priority panel */}
                    <div className="lg:col-span-7 bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl space-y-4">
                      <div>
                        <h4 className="text-xs font-bold uppercase tracking-wider text-white">Shapley Values Weight Breakdown</h4>
                        <p className="text-[11px] text-slate-500">Shows relative scientific impact weight factors on prediction final classification</p>
                      </div>

                      <div className="space-y-5 py-2">
                        {mockFeatureImportances.map((f, i) => {
                          const isPositive = f.shapValue > 0;
                          const fillWidth = Math.round(Math.abs(f.shapValue) * 350);
                          return (
                            <div key={f.featureName} className="space-y-2 border-b border-white/5 pb-2">
                              <div className="flex justify-between text-xs">
                                <div>
                                  <span className="font-bold text-white">{f.featureName}</span>
                                  <p className="text-[10px] text-slate-500 leading-tight mt-0.5">{f.description}</p>
                                </div>
                                <div className="text-right font-mono text-xs">
                                  <div className="font-bold text-slate-300">Score weight: {f.score}</div>
                                  <div className={isPositive ? "text-rose-400 font-medium" : "text-cyan-400 font-medium"}>
                                    {isPositive ? "+" : ""}{f.shapValue} SHAP
                                  </div>
                                </div>
                              </div>

                              <div className="flex h-2.5 bg-slate-900 rounded-full overflow-hidden border border-white/5 relative">
                                <div 
                                  className={`h-full ${isPositive ? 'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.4)]' : 'bg-[#00f0ff] shadow-[0_0_8px_rgba(0,240,255,0.4)]'}`} 
                                  style={{ width: `${Math.min(100, Math.max(3, Math.abs(f.score) * 180 + 35))}%` }}
                                ></div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Pathologist Clinical decision explanation panel */}
                    <div className="lg:col-span-5 space-y-6">
                      
                      <div className="bg-gradient-to-b from-cyan-950/40 to-transparent border border-cyan-500/30 rounded-2xl p-5 backdrop-blur-xl space-y-4">
                        <div>
                          <div className="flex items-center gap-2">
                            <Sparkles className="w-4 h-4 text-cyan-400" />
                            <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-300">AI Pathology Annotation Core</h4>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-1">Direct computational diagnostics for candidate variant: **{activeVariant.id}**</p>
                        </div>

                        <div className="bg-black/40 rounded-xl p-4 border border-white/5 space-y-3 font-mono text-xs text-slate-300">
                          <div>
                            <span className="text-slate-500">Empirical gene:</span> <span className="text-white font-bold">{activeVariant.gene}</span>
                          </div>
                          <div>
                            <span className="text-slate-500">Consequence coordinate:</span> <span className="text-white">{activeVariant.consequence} ({activeVariant.id.split(':')[1]})</span>
                          </div>
                          <div>
                            <span className="text-slate-500">Sub-Pop recurrence gnomAD:</span> <span className="text-[#00f0ff]">{activeVariant.alleleFrequency}</span>
                          </div>
                          <div>
                            <span className="text-slate-500">CADD conservation:</span> <span className="text-[#b026ff]">{activeVariant.caddScore}</span>
                          </div>
                          <div>
                            <span className="text-slate-500">REVEL metric:</span> <span className="text-cyan-400">{activeVariant.revelScore}</span>
                          </div>
                        </div>

                        <div className="p-3 bg-black/60 rounded-xl border border-cyan-500/20 text-xs text-slate-200 leading-relaxed font-sans">
                          {activeVariant.clinicalInterpretation}
                        </div>

                        {/* Action buttons triggers Chat helper context */}
                        <button 
                          onClick={() => {
                            setActiveTab("assistant");
                            handleSendChatMessage(`Provide deep clinical treatment guidelines for somatic ${activeVariant.gene} variant with ID ${activeVariant.id}`);
                          }}
                          className="w-full bg-[#00f0ff] hover:bg-cyan-400 text-black font-semibold font-mono text-xs py-2.5 rounded-lg uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(0,240,255,0.25)]"
                        >
                          <BookOpen className="w-4 h-4" />
                          Consult Pathogen Literature
                        </button>
                      </div>

                      {/* Targeted Therapeutic matches block */}
                      <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl space-y-3">
                        <div className="flex items-center gap-2 text-rose-400 text-xs font-bold uppercase tracking-wider">
                          <Flame className="w-4.5 h-4.5" />
                          Matched FDA Therapeutic Guidelines
                        </div>
                        
                        <p className="text-xs text-slate-400 leading-relaxed">
                          This variant is linked in somatic registries to therapeutic sensitivity thresholds. Clinical trials highlight candidate matched agents:
                        </p>

                        <div className="space-y-2 pt-2 text-xs">
                          <div className="bg-white/5 border border-white/5 p-3 rounded-xl flex justify-between items-center">
                            <div>
                              <span className="font-bold text-white block">TKI Kinase Inhibitor Class</span>
                              <span className="text-[10px] text-cyan-400 font-mono">Matched for EGFR p.L858R / KRAS G12C</span>
                            </div>
                            <ExternalLink className="w-4 h-4 text-slate-500" />
                          </div>

                          <div className="bg-white/5 border border-white/5 p-3 rounded-xl flex justify-between items-center">
                            <div>
                              <span className="font-bold text-white block">PARP homologous repair inhibitor</span>
                              <span className="text-[10px] text-purple-400 font-mono">Matched for BRCA1 truncation alleles</span>
                            </div>
                            <ExternalLink className="w-4 h-4 text-slate-500" />
                          </div>
                        </div>
                      </div>

                    </div>

                  </div>

                </div>
              )}

              {/* ==================== SUB-PAGE 5: PREDICTION HISTORY PAGE ==================== */}
              {activeTab === "history" && (
                <div className="space-y-6 animate-fade-in">
                  
                  <div>
                    <h3 className="text-lg font-bold text-white uppercase tracking-wider">Prediction History & Screening Jobs</h3>
                    <p className="text-xs text-slate-400">View and reload predictions performed on somatic sequenced runs.</p>
                  </div>

                  <div className="space-y-4">
                    {jobsList.map((job) => (
                      <div 
                        key={job.id} 
                        className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4 hover:border-cyan-500/30 transition-all cursor-pointer"
                        onClick={() => {
                          setVariantsList(job.results);
                          setSelectedVariantId(job.results[0]?.id || null);
                          triggerToast(`Switched active workspace to ${job.name}.`, "info");
                          setActiveTab("dashboard");
                        }}
                      >
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono bg-cyan-500/15 text-cyan-300 font-bold px-2.5 py-0.5 rounded border border-cyan-500/25">
                              {job.id}
                            </span>
                            <h4 className="text-sm font-bold text-white">{job.name}</h4>
                          </div>

                          <div className="flex flex-wrap gap-4 text-xs text-slate-500 font-mono">
                            <span>Computed Date: {job.date}</span>
                            <span>Target Count: {job.variantCount} variants</span>
                            <span>Model configured: {job.modelUsed}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-4 w-full md:w-auto justify-between md:justify-end border-t md:border-t-0 border-white/5 pt-3 md:pt-0">
                          <div className="flex items-center gap-2">
                            <span className="flex h-2 w-2 rounded-full bg-green-400"></span>
                            <span className="text-xs font-mono text-green-400 uppercase tracking-tighter">Diagnostic Run complete</span>
                          </div>
                          
                          <button className="text-xs font-mono font-bold bg-[#00f0ff]/15 hover:bg-[#00f0ff]/25 text-[#00f0ff] border border-[#00f0ff]/30 rounded-lg px-4 py-2 transition-all">
                            Load Workspace
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                </div>
              )}

              {/* ==================== SUB-PAGE 6: AI助理 CHAT INTERFACE ==================== */}
              {activeTab === "assistant" && (
                <div className="space-y-6 animate-fade-in flex flex-col h-[calc(100vh-12rem)]">
                  
                  <div className="shrink-0 flex justify-between items-center pb-2 border-b border-white/5">
                    <div>
                      <h3 className="text-lg font-bold text-white uppercase tracking-wider">OncoSage Research Chat Core</h3>
                      <p className="text-xs text-slate-400">Ask questions regarding targeted oncology therapeutics, pathogenic databases, protein alignment mutations, or CADD scoring parameters.</p>
                    </div>

                    <div className="hidden sm:inline-flex items-center gap-2 px-3 py-1 bg-cyan-500/10 border border-cyan-500/20 rounded-full text-[10px] text-cyan-400 font-mono">
                      <span>Online AI Engine state: Gemini Stable</span>
                    </div>
                  </div>

                  {/* Chat messages listing container */}
                  <div className="flex-1 overflow-y-auto bg-black/40 border border-white/10 rounded-2xl p-5 space-y-4">
                    {chatHistory.map((item) => {
                      const isUser = item.sender === "user";
                      return (
                        <div 
                          key={item.id} 
                          className={`flex gap-3 max-w-3xl ${isUser ? 'ml-auto flex-row-reverse' : ''}`}
                        >
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                            isUser ? 'bg-purple-600/20 text-purple-400' : 'bg-cyan-500/20 text-cyan-400'
                          }`}>
                            {isUser ? <User className="w-4.5 h-4.5" /> : <Sparkles className="w-4.5 h-4.5" />}
                          </div>

                          <div className={`p-4 rounded-2xl text-xs leading-relaxed ${
                            isUser ? 'bg-purple-950/30 border border-purple-500/20 text-slate-200' : 'bg-white/[0.02] border border-white/5 text-slate-300'
                          }`}>
                            {/* Simple Markdown headers and bold styles parser */}
                            <p className="whitespace-pre-wrap">
                              {item.text.split("\n").map((line, idx) => {
                                if (line.startsWith("### ")) {
                                  return <h4 key={idx} className="text-sm font-extrabold text-white uppercase mt-4 mb-2 first:mt-0">{line.replace("### ", "")}</h4>;
                                }
                                if (line.startsWith("- ")) {
                                  return <li key={idx} className="list-disc ml-4 mb-1 text-slate-300">{line.replace("- ", "")}</li>;
                                }
                                return (
                                  <span key={idx} className="block mt-1">
                                    {line.split("**").map((chunk, cIdx) => 
                                      cIdx % 2 === 1 ? <strong key={cIdx} className="text-white bg-white/5 px-1 py-0.5 rounded">{chunk}</strong> : chunk
                                    )}
                                  </span>
                                );
                              })}
                            </p>
                            <span className="block text-[10px] text-slate-500 text-right mt-2 font-mono">{item.timestamp}</span>
                          </div>
                        </div>
                      );
                    })}
                    
                    {isTyping && (
                      <div className="flex gap-3 max-w-sm">
                        <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                          <Cpu className="w-4.5 h-4.5 animate-spin" />
                        </div>
                        <div className="bg-white/[0.01] border border-white/5 p-4 rounded-xl text-xs text-cyan-400 animate-pulse italic">
                          Compiling diagnostic indices across oncology clinical pathways...
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Predefined prompt helpers */}
                  <div className="shrink-0 flex flex-wrap gap-2 py-2">
                    <button 
                      onClick={() => handleSendChatMessage("Explain TP53 pathogenic hotspot R273H consequences in detail.")}
                      className="text-[11px] bg-white/5 border border-white/5 hover:border-cyan-500/30 text-slate-300 rounded-lg px-3 py-1.5 hover:text-white transition-all"
                    >
                      💡 TP53 hotspot p.R273H
                    </button>
                    <button 
                      onClick={() => handleSendChatMessage("How do we use CADD score thresholds to filter clinical tumor somatic variants?")}
                      className="text-[11px] bg-white/5 border border-white/5 hover:border-cyan-500/30 text-slate-300 rounded-lg px-3 py-1.5 hover:text-white transition-all"
                    >
                      💡 How does CADD work?
                    </button>
                    <button 
                      onClick={() => handleSendChatMessage("What targeted therapies coordinate with mutations inside EGFR Exon 21 or BRAF V600E?")}
                      className="text-[11px] bg-white/5 border border-white/5 hover:border-cyan-500/30 text-slate-300 rounded-lg px-3 py-1.5 hover:text-white transition-all"
                    >
                      💡 Targeted drug matches
                    </button>
                  </div>

                  {/* Input form */}
                  <div className="shrink-0 flex gap-2">
                    <input 
                      type="text" 
                      placeholder="Discuss oncology sequences files, clinical targets, or SIFT indices..."
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSendChatMessage()}
                      className="flex-1 bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                    />

                    <button 
                      onClick={() => handleSendChatMessage()}
                      className="bg-cyan-500 hover:bg-cyan-400 text-black font-semibold font-mono text-xs px-6 py-3 rounded-xl transition-all uppercase tracking-wider"
                    >
                      Transmit query
                    </button>
                  </div>

                </div>
              )}

              {/* ==================== SUB-PAGE 7: CONFIGURATION CONFIGS ==================== */}
              {activeTab === "settings" && (
                <div className="space-y-6 animate-fade-in">
                  
                  <div>
                    <h3 className="text-lg font-bold text-white uppercase tracking-wider">System Settings & Calibration</h3>
                    <p className="text-xs text-slate-400">Configure thresholds, modify investigator credentials, toggle themes, and audit security setups.</p>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    
                    {/* Panel 1: Profile */}
                    <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl space-y-4">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Investigator Personal Identity</h4>
                      
                      <div className="flex gap-4 items-center">
                        <div className="w-16 h-16 rounded-full border-2 border-cyan-400 overflow-hidden shrink-0">
                          <img src={userProfile.avatar} alt="Profile" className="w-full h-full object-cover" />
                        </div>
                        <div className="space-y-1">
                          <div className="text-xs text-slate-400">Upload profile image URL:</div>
                          <input 
                            type="text" 
                            value={userProfile.avatar} 
                            onChange={(e) => setUserProfile({...userProfile, avatar: e.target.value})}
                            className="bg-black/30 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-400 w-full"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 text-xs">
                        <div className="space-y-1">
                          <span className="text-slate-400 font-mono">Investigator Name:</span>
                          <input 
                            type="text" 
                            value={userProfile.name}
                            onChange={(e) => setUserProfile({...userProfile, name: e.target.value})}
                            className="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-xs text-slate-200"
                          />
                        </div>

                        <div className="space-y-1">
                          <span className="text-slate-400 font-mono">Email Address:</span>
                          <input 
                            type="text" 
                            value={userProfile.email}
                            onChange={(e) => setUserProfile({...userProfile, email: e.target.value})}
                            className="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-xs text-slate-200"
                          />
                        </div>

                        <div className="space-y-1 col-span-2">
                          <span className="text-slate-400 font-mono">Affiliated Lab/Institution:</span>
                          <input 
                            type="text" 
                            value={userProfile.institution}
                            onChange={(e) => setUserProfile({...userProfile, institution: e.target.value})}
                            className="w-full bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-xs text-slate-200"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Panel 2: UI configuration constraints */}
                    <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 backdrop-blur-xl space-y-4">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Interface Variations & Threshold weights</h4>

                      <div className="space-y-4 pt-2 text-xs">
                        {/* Dark/Light style selector */}
                        <div className="flex justify-between items-center bg-black/20 p-3 rounded-xl border border-white/5">
                          <div>
                            <span className="font-bold text-white block">Theme Aesthetics Override</span>
                            <span className="text-[10px] text-slate-400">Selected standard biotech Frosted Glass Theme</span>
                          </div>
                          <button 
                            onClick={() => {
                              setIsLightMode(!isLightMode);
                              triggerToast(`Swapped look to ${!isLightMode ? 'Light glass' : 'Deep dark glass'} layout.`, "info");
                            }}
                            className="bg-white/5 border border-white/10 hover:border-cyan-500/30 text-white rounded-lg px-4 py-2 transition-all uppercase font-mono text-[10px]"
                          >
                            {isLightMode ? "Switch Dark mode" : "Switch Light mode"}
                          </button>
                        </div>

                        {/* Adjust features relative contribution parameters sliders */}
                        <div className="space-y-3.5 pt-3">
                          <span className="text-[10px] font-mono text-purple-400 uppercase font-bold tracking-widest block">Fine-tune ensemble weight ratios</span>
                          
                          {/* Weight parameter REVEL info */}
                          <div className="space-y-1">
                            <div className="flex justify-between text-xs text-slate-400">
                              <span>REVEL pathogenicity multiplier:</span>
                              <span className="font-mono text-cyan-400 font-bold">{userSettings.revelWeight}</span>
                            </div>
                            <input 
                              type="range" 
                              min="0" 
                              max="0.60" 
                              step="0.05" 
                              value={userSettings.revelWeight}
                              onChange={(e) => setUserSettings({...userSettings, revelWeight: Number(e.target.value)})}
                              className="w-full h-1 bg-slate-800 accent-cyan-400 rounded-lg cursor-pointer"
                            />
                          </div>

                          {/* Weight parameter CADD info */}
                          <div className="space-y-1">
                            <div className="flex justify-between text-xs text-slate-400">
                              <span>CADD deleteriousness multiplier:</span>
                              <span className="font-mono text-purple-400 font-bold">{userSettings.caddWeight}</span>
                            </div>
                            <input 
                              type="range" 
                              min="0" 
                              max="0.60" 
                              step="0.05" 
                              value={userSettings.caddWeight}
                              onChange={(e) => setUserSettings({...userSettings, caddWeight: Number(e.target.value)})}
                              className="w-full h-1 bg-slate-800 accent-purple-400 rounded-lg cursor-pointer"
                            />
                          </div>
                        </div>

                        <div className="bg-cyan-500/5 p-3 rounded-xl border border-cyan-500/10 text-[10px] text-slate-500">
                          *System Automatically normalizes weight totals when executing backend Python/tsx predictors. Ensure total scores match laboratory protocols.
                        </div>

                      </div>
                    </div>

                  </div>

                </div>
              )}

            </div>

            {/* Status Bar / Footer (Frosted glass footer) */}
            <footer className="mt-auto px-6 py-4 flex flex-col sm:flex-row justify-between items-center text-[9px] font-mono text-slate-500 border-t border-white/5 bg-black/20 backdrop-blur-xl gap-2 tracking-widest uppercase">
              <div className="flex gap-6">
                <span>Region: ASIA-EAST-1</span>
                <span>Latency: ok (18ms)</span>
                <span>Processor: Deep-OncoSage-H100</span>
              </div>
              <div>&copy; 2026 ONCOSAGE INTEGRATIVE GENOMIC SERVICES. ALL LAB TESTING UNDER CONSTANT PROTOCOL.</div>
            </footer>

          </main>
        </div>
      )}

      {/* ==================== MODAL A: NEW ANALYSIS VARIANT DIALOG ==================== */}
      {showAddVariantModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#0b1329] border border-cyan-500/30 rounded-3xl p-6 max-w-xl w-full max-h-[90vh] overflow-y-auto relative shadow-[0_0_50px_rgba(34,211,238,0.15)] animate-fade-in text-slate-100">
            
            <button 
              onClick={() => setShowAddVariantModal(false)}
              className="absolute top-4 right-4 p-2 rounded-lg bg-white/5 border border-white/10 hover:border-cyan-400 transition-colors text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3.5 mb-5">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400">
                <Dna className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-extrabold uppercase tracking-widest text-white">Inject Somatic Variant Panel Locus</h3>
                <p className="text-[10px] text-slate-400 uppercase mt-0.5">Specify molecular coordinates parameters for deep AI prediction</p>
              </div>
            </div>

            {/* Custom Formulation for Genomic Variant Calculation parameters */}
            <form onSubmit={handleAddCustomVariant} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                
                {/* Gene symbol */}
                <div className="space-y-1">
                  <label className="text-slate-400 font-mono">Target Gene symbol:</label>
                  <input 
                    type="text" 
                    value={newVarGene} 
                    onChange={(e) => setNewVarGene(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-slate-100"
                    placeholder="e.g. EGFR" 
                    required 
                  />
                </div>

                {/* Chromsome chromosome */}
                <div className="space-y-1">
                  <label className="text-slate-400 font-mono">Chromosome:</label>
                  <select 
                    value={newVarChr} 
                    onChange={(e) => setNewVarChr(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-slate-100 placeholder-slate-500 focus:outline-none"
                  >
                    <option value="Chr3">Chr3</option>
                    <option value="Chr7">Chr7</option>
                    <option value="Chr10">Chr10</option>
                    <option value="Chr12">Chr12</option>
                    <option value="Chr13">Chr13</option>
                    <option value="Chr11">Chr11</option>
                    <option value="Chr17">Chr17</option>
                  </select>
                </div>

                {/* Chronosome position */}
                <div className="space-y-1">
                  <label className="text-slate-400 font-mono">Locus Position:</label>
                  <input 
                    type="number" 
                    value={newVarPos} 
                    onChange={(e) => setNewVarPos(Number(e.target.value))}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-slate-100"
                    required 
                  />
                </div>

                {/* Base reference ref */}
                <div className="space-y-1">
                  <label className="text-slate-400 font-mono">Ref allele:</label>
                  <input 
                    type="text" 
                    maxLength={1}
                    value={newVarRef} 
                    onChange={(e) => setNewVarRef(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-slate-100 uppercase"
                    required 
                  />
                </div>

                {/* Alt allele alternative */}
                <div className="space-y-1">
                  <label className="text-slate-400 font-mono">Alt allele alternative:</label>
                  <input 
                    type="text" 
                    maxLength={1}
                    value={newVarAlt} 
                    onChange={(e) => setNewVarAlt(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-slate-100 uppercase"
                    required 
                  />
                </div>

                {/* Consequence classification selection */}
                <div className="space-y-1">
                  <label className="text-slate-400 font-mono">Consequence:</label>
                  <select 
                    value={newVarConsequence} 
                    onChange={(e) => setNewVarConsequence(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-slate-100"
                  >
                    <option value="Missense">Missense</option>
                    <option value="Nonsense">Nonsense</option>
                    <option value="Frameshift">Frameshift</option>
                    <option value="Synonymous">Synonymous</option>
                  </select>
                </div>

              </div>

              {/* Bioinformatic indicators parameters inputs */}
              <div className="border-t border-white/5 pt-4">
                <span className="text-[10px] font-mono uppercase tracking-widest text-purple-400 font-bold block mb-3">Bioinformatics indicators metrics input</span>
                
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="space-y-1">
                    <label className="text-slate-400 font-mono">CADD (0-40)</label>
                    <input 
                      type="number" 
                      step="0.1"
                      min="0"
                      max="40"
                      value={newVarCadd} 
                      onChange={(e) => setNewVarCadd(Number(e.target.value))}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-2.5 py-1.5 text-slate-100"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-slate-400 font-mono">REVEL (0-1)</label>
                    <input 
                      type="number" 
                      step="0.01"
                      min="0"
                      max="1"
                      value={newVarRevel} 
                      onChange={(e) => setNewVarRevel(Number(e.target.value))}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-2.5 py-1.5 text-slate-100"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-slate-400 font-mono">PolyPhen-2</label>
                    <input 
                      type="number" 
                      step="0.01"
                      min="0"
                      max="1"
                      value={newVarPolyPhen} 
                      onChange={(e) => setNewVarPolyPhen(Number(e.target.value))}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-2.5 py-1.5 text-slate-100"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-slate-400 font-mono">SIFT (0-1)</label>
                    <input 
                      type="number" 
                      step="0.01"
                      min="0"
                      max="1"
                      value={newVarSift} 
                      onChange={(e) => setNewVarSift(Number(e.target.value))}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-2.5 py-1.5 text-slate-100"
                    />
                  </div>

                  <div className="space-y-1 col-span-2">
                    <label className="text-slate-400 font-mono">gnomAD Allele Freq</label>
                    <input 
                      type="number" 
                      step="0.000001"
                      min="0"
                      max="0.5"
                      value={newVarGnomad} 
                      onChange={(e) => setNewVarGnomad(Number(e.target.value))}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-2.5 py-1.5 text-slate-100 font-mono"
                    />
                  </div>

                  <div className="space-y-1 col-span-2">
                    <label className="text-slate-400 font-mono">GERP++ Conservation</label>
                    <input 
                      type="number" 
                      step="0.01"
                      min="0"
                      max="1"
                      value={newVarConservation} 
                      onChange={(e) => setNewVarConservation(Number(e.target.value))}
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-2.5 py-1.5 text-slate-100 font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Submitting Button */}
              <div className="flex gap-3 justify-end pt-5 border-t border-white/5">
                <button 
                  type="button" 
                  onClick={() => setShowAddVariantModal(false)}
                  className="bg-white/5 border border-white/10 hover:bg-white/10 text-white rounded-xl px-5 py-2.5 text-xs font-mono transition-colors uppercase font-bold"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="bg-gradient-to-r from-cyan-400 to-sky-500 hover:scale-101 text-black font-semibold font-mono text-xs px-6 py-2.5 rounded-xl uppercase transition-all shadow-[0_0_20px_rgba(34,211,238,0.4)] flex items-center gap-2"
                >
                  {isSubmittingVariant ? (
                    <>
                      <Cpu className="w-4 h-4 animate-spin" strokeWidth={3} />
                      Classifying Sequence...
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4" strokeWidth={3} />
                      Run AI Predictor
                    </>
                  )}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* ==================== MODAL B: EXPORT CLINICAL REPORT DIALOG ==================== */}
      {showExportModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#0b1329] border border-white/10 rounded-3xl p-6 max-w-md w-full relative shadow-[0_0_50px_rgba(0,240,255,0.1)] text-slate-100">
            <button 
              onClick={() => setShowExportModal(false)}
              className="absolute top-4 right-4 p-2 rounded-lg bg-white/5 border border-white/10 hover:border-cyan-400 transition-colors text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <FileText className="w-6 h-6 text-cyan-400" />
              <div>
                <h3 className="text-sm font-bold uppercase tracking-wider text-white">Export Pathological Verdict</h3>
                <p className="text-[10px] text-slate-400 uppercase mt-0.5">Generate laboratory diagnosis paperwork files</p>
              </div>
            </div>

            <div className="space-y-4 text-xs pt-2">
              <p className="text-slate-300 leading-relaxed">
                Confirm exporting standard clinical annotating reports for target candidate locus: **{activeVariant.id}** ({activeVariant.gene}).
              </p>

              <div className="bg-black/30 p-3 rounded-xl border border-cyan-500/10 space-y-2">
                <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-widest block">Paperwork structure preferences:</span>
                <div className="space-y-1 text-slate-400 font-mono">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="radio" 
                      name="reportType" 
                      checked={exportReportType === "clinical"} 
                      onChange={() => setExportReportType("clinical")}
                      className="accent-cyan-400"
                    />
                    <span>Integrated Clinical summary statement (.txt)</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="radio" 
                      name="reportType" 
                      checked={exportReportType === "academic"} 
                      onChange={() => setExportReportType("academic")}
                      className="accent-cyan-400"
                    />
                    <span>Scholarly deep pathways citation summary (.txt)</span>
                  </label>
                </div>
              </div>

              <div className="flex gap-3 justify-end pt-4 border-t border-white/5">
                <button 
                  onClick={() => setShowExportModal(false)}
                  className="bg-white/5 border border-white/10 text-white rounded-lg px-4 py-2 transition-all uppercase font-mono text-[10px]"
                >
                  Cancel
                </button>
                <button 
                  onClick={triggerDiagnosticReportDownload}
                  className="bg-cyan-500 hover:bg-cyan-400 text-black font-semibold font-mono text-[10px] px-5 py-2 rounded-lg uppercase tracking-wider transition-all shadow-[0_0_15px_rgba(0,192,255,0.25)] flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  Generate Downloadable File
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
