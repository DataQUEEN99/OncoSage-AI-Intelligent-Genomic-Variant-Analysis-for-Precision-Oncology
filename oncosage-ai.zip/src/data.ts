/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GenomicVariant, ModelMetrics, FeatureImportance, PredictionJob } from './types';

export const sampleVariants: GenomicVariant[] = [
  {
    id: "chr17:g.7577120G>A",
    gene: "TP53",
    chromosome: "Chr17",
    position: 7577120,
    refAllele: "G",
    altAllele: "A",
    consequence: "Missense",
    caddScore: 32.4,
    polyphenScore: 0.98,
    siftScore: 0.01,
    alleleFrequency: 0.00002,
    revelScore: 0.91,
    conservationScore: 0.89,
    pathogenicity: "Pathogenic",
    confidence: 96.8,
    riskLevel: "Critical",
    clinicalInterpretation: "This hotspot p.R273H mutation disrupts TP53's DNA binding domain, leading to critical loss of tumor suppressor function. Highly associated with Li-Fraumeni syndrome and multiple somatic cancers."
  },
  {
    id: "chr7:g.55241707G>T",
    gene: "EGFR",
    chromosome: "Chr7",
    position: 55241707,
    refAllele: "G",
    altAllele: "T",
    consequence: "Missense",
    caddScore: 28.1,
    polyphenScore: 0.95,
    siftScore: 0.03,
    alleleFrequency: 0.000005,
    revelScore: 0.88,
    conservationScore: 0.92,
    pathogenicity: "Pathogenic",
    confidence: 93.4,
    riskLevel: "High",
    clinicalInterpretation: "The p.L858R mutation resides within the kinase domain of EGFR, causing constitutive kinase activation. Predictive of strong sensitivity to first, second, and third-generation EGFR tyrosine kinase inhibitors (TKIs) like Osimertinib."
  },
  {
    id: "chr7:g.140453136A>T",
    gene: "BRAF",
    chromosome: "Chr7",
    position: 140453136,
    refAllele: "A",
    altAllele: "T",
    consequence: "Missense",
    caddScore: 34.0,
    polyphenScore: 0.99,
    siftScore: 0.00,
    alleleFrequency: 0.000001,
    revelScore: 0.96,
    conservationScore: 0.97,
    pathogenicity: "Pathogenic",
    confidence: 98.7,
    riskLevel: "Critical",
    clinicalInterpretation: "The p.V600E kinase activation hotspot mimic phosphorylation in the activation segment. Highly prevalent in melanoma, colorectal, and thyroid cancers. Highly responsive to combination Raf/Mek inhibitor therapies (Dabrafenib/Trametinib)."
  },
  {
    id: "chr17:g.41243432T>A",
    gene: "BRCA1",
    chromosome: "Chr17",
    position: 41243432,
    refAllele: "T",
    altAllele: "A",
    consequence: "Nonsense",
    caddScore: 38.2,
    polyphenScore: 1.00,
    siftScore: 0.00,
    alleleFrequency: 0.000008,
    revelScore: 0.95,
    conservationScore: 0.81,
    pathogenicity: "Pathogenic",
    confidence: 99.1,
    riskLevel: "Critical",
    clinicalInterpretation: "Premature stop codon (p.Y97X) resulting in truncated, non-functional BRCA1 protein. Associated with hereditary breast and ovarian cancer syndrome. Strong indicator for PARP inhibitor sensitivity (Olaparib, Talazoparib)."
  },
  {
    id: "chr3:g.178936091G>A",
    gene: "PIK3CA",
    chromosome: "Chr3",
    position: 178936091,
    refAllele: "G",
    altAllele: "A",
    consequence: "Missense",
    caddScore: 24.6,
    polyphenScore: 0.88,
    siftScore: 0.05,
    alleleFrequency: 0.00014,
    revelScore: 0.79,
    conservationScore: 0.78,
    pathogenicity: "Pathogenic",
    confidence: 89.2,
    riskLevel: "High",
    clinicalInterpretation: "The p.H1047R substitution in the kinase domain induces constitutive PI3K pathway activation. Direct therapeutic match for FDA-approved PI3K-alpha inhibitors such as Alpelisib in breast oncology."
  },
  {
    id: "chr10:g.89692900C>G",
    gene: "PTEN",
    chromosome: "Chr10",
    position: 89692900,
    refAllele: "C",
    altAllele: "G",
    consequence: "Missense",
    caddScore: 27.8,
    polyphenScore: 0.91,
    siftScore: 0.02,
    alleleFrequency: 0.000012,
    revelScore: 0.84,
    conservationScore: 0.85,
    pathogenicity: "Pathogenic",
    confidence: 91.5,
    riskLevel: "High",
    clinicalInterpretation: "Functional inactivation of PTEN lipid phosphatase activity, leading to hyperactivation of Akt pathway. Associated with Cowden syndrome and substantial somatic tumor growth."
  },
  {
    id: "chr12:g.25398284C>A",
    gene: "KRAS",
    chromosome: "Chr12",
    position: 25398284,
    refAllele: "C",
    altAllele: "A",
    consequence: "Missense",
    caddScore: 29.3,
    polyphenScore: 0.94,
    siftScore: 0.01,
    alleleFrequency: 0.000004,
    revelScore: 0.89,
    conservationScore: 0.91,
    pathogenicity: "Pathogenic",
    confidence: 95.2,
    riskLevel: "Critical",
    clinicalInterpretation: "The p.G12C mutation alters KRAS, maintaining it in an active, GTP-bound regulatory state. Predicts resistance to EGFR antibodies, but qualifies patients for novel allele-specific inhibitors like Sotorasib."
  },
  {
    id: "chr13:g.32914437A>G",
    gene: "BRCA2",
    chromosome: "Chr13",
    position: 32914437,
    refAllele: "A",
    altAllele: "G",
    consequence: "Synonymous",
    caddScore: 5.4,
    polyphenScore: 0.12,
    siftScore: 0.85,
    alleleFrequency: 0.014,
    revelScore: 0.08,
    conservationScore: 0.15,
    pathogenicity: "Benign",
    confidence: 98.4,
    riskLevel: "Low",
    clinicalInterpretation: "Common codon alteration (p.L1523=) which preserves wild-type splicing signals and maintains normal homologous recombination. Documented as a benign polymorphism."
  },
  {
    id: "chr11:g.108098342G>A",
    gene: "ATM",
    chromosome: "Chr11",
    position: 108098342,
    refAllele: "G",
    altAllele: "A",
    consequence: "Missense",
    caddScore: 16.2,
    polyphenScore: 0.45,
    siftScore: 0.18,
    alleleFrequency: 0.0018,
    revelScore: 0.32,
    conservationScore: 0.48,
    pathogenicity: "VUS",
    confidence: 72.1,
    riskLevel: "Medium",
    clinicalInterpretation: "A variant of uncertain clinical significance (VUS). High-throughput functional screenings demonstrate moderate DNA repair proficiency, though family segregation data remains inconclusive."
  },
  {
    id: "chr5:g.112175951G>A",
    gene: "APC",
    chromosome: "Chr5",
    position: 112175951,
    refAllele: "G",
    altAllele: "A",
    consequence: "Nonsense",
    caddScore: 35.1,
    polyphenScore: 1.00,
    siftScore: 0.00,
    alleleFrequency: 0.000003,
    revelScore: 0.94,
    conservationScore: 0.88,
    pathogenicity: "Pathogenic",
    confidence: 97.9,
    riskLevel: "High",
    clinicalInterpretation: "The p.R1450X truncation generates a shortened APC protein lacking key beta-catenin interaction repeats. Triggers constitutively high Wnt pathway activation, associated with Familial Adenomatous Polyposis."
  }
];

export const mockFeatureImportances: FeatureImportance[] = [
  {
    featureName: "REVEL Score",
    score: 0.28,
    shapValue: 0.182,
    description: "Ensemble predictor utilizing multiple in silico tools, specifically optimized for missense variants."
  },
  {
    featureName: "CADD Score",
    score: 0.23,
    shapValue: 0.145,
    description: "Combined Annotation Dependent Depletion score integrating genomic signatures and evolutionary context."
  },
  {
    featureName: "Allele Frequency",
    score: 0.18,
    shapValue: -0.124,
    description: "Frequencies calculated from global healthy cohorts (gnomAD). High frequency heavily shifts prediction to Benign."
  },
  {
    featureName: "PolyPhen-2",
    score: 0.13,
    shapValue: 0.089,
    description: "Sequence and structure-based predictions analyzing specific amino acid substitutions in proteins."
  },
  {
    featureName: "Conservation GERP++",
    score: 0.11,
    shapValue: 0.072,
    description: "Evolutionary constraint metrics measuring rate of substitution across mammalian sequence alignments."
  },
  {
    featureName: "SIFT Score",
    score: 0.07,
    shapValue: -0.045,
    description: "Sequence homology-based alignment profiling predicting if amino acid change affects protein operations."
  }
];

export const defaultModelMetrics: Record<string, ModelMetrics> = {
  "OncoSage-RandomForest V2": {
    accuracy: 0.948,
    auc: 0.979,
    precision: 0.942,
    recall: 0.954,
    f1Score: 0.948,
    rocCurve: [
      { fpr: 0, tpr: 0 },
      { fpr: 0.01, tpr: 0.42 },
      { fpr: 0.03, tpr: 0.78 },
      { fpr: 0.05, tpr: 0.91 },
      { fpr: 0.08, tpr: 0.95 },
      { fpr: 0.15, tpr: 0.97 },
      { fpr: 0.30, tpr: 0.98 },
      { fpr: 0.60, tpr: 0.99 },
      { fpr: 1.0, tpr: 1.0 }
    ],
    confusionMatrix: {
      truePositive: 477,
      falsePositive: 29,
      trueNegative: 471,
      falseNegative: 23
    }
  },
  "OncoSage-XGBoost Neural V3": {
    accuracy: 0.965,
    auc: 0.991,
    precision: 0.961,
    recall: 0.968,
    f1Score: 0.964,
    rocCurve: [
      { fpr: 0, tpr: 0 },
      { fpr: 0.005, tpr: 0.51 },
      { fpr: 0.015, tpr: 0.85 },
      { fpr: 0.03, tpr: 0.94 },
      { fpr: 0.05, tpr: 0.97 },
      { fpr: 0.10, tpr: 0.98 },
      { fpr: 0.25, tpr: 0.992 },
      { fpr: 0.50, tpr: 0.997 },
      { fpr: 1.0, tpr: 1.0 }
    ],
    confusionMatrix: {
      truePositive: 484,
      falsePositive: 19,
      trueNegative: 481,
      falseNegative: 16
    }
  },
  "OncoSage-LogRegression V1": {
    accuracy: 0.892,
    auc: 0.924,
    precision: 0.887,
    recall: 0.895,
    f1Score: 0.891,
    rocCurve: [
      { fpr: 0, tpr: 0 },
      { fpr: 0.05, tpr: 0.35 },
      { fpr: 0.10, tpr: 0.68 },
      { fpr: 0.15, tpr: 0.82 },
      { fpr: 0.22, tpr: 0.89 },
      { fpr: 0.35, tpr: 0.93 },
      { fpr: 0.55, tpr: 0.96 },
      { fpr: 0.80, tpr: 0.98 },
      { fpr: 1.0, tpr: 1.0 }
    ],
    confusionMatrix: {
      truePositive: 448,
      falsePositive: 57,
      trueNegative: 443,
      falseNegative: 52
    }
  }
};

export const initialJobs: PredictionJob[] = [
  {
    id: "JOB-72D98",
    name: "Somatic Variant Panel - Colorectal Co-12",
    date: "2026-05-24 14:22 UTC",
    variantCount: 154,
    status: "Completed",
    modelUsed: "OncoSage-XGBoost Neural V3",
    results: sampleVariants.slice(0, 5)
  },
  {
    id: "JOB-48C21",
    name: "Germline Breast Screening - Fam_34_Pro",
    date: "2026-05-25 09:12 UTC",
    variantCount: 42,
    status: "Completed",
    modelUsed: "OncoSage-RandomForest V2",
    results: [sampleVariants[3], sampleVariants[7], sampleVariants[8]]
  },
  {
    id: "JOB-91E33",
    name: "Glioma Biopsy Variant Profiling",
    date: "2026-05-26 06:15 UTC",
    variantCount: 98,
    status: "Completed",
    modelUsed: "OncoSage-XGBoost Neural V3",
    results: sampleVariants.slice(4, 9)
  }
];

export const sampleUserDatabase = {
  profile: {
    name: "Dr. Eleanor Vance, PhD",
    email: "khushikumari.analytics@gmail.com",
    institution: "Institute for Precision Oncology, AI Division",
    role: "Senior Genomics Researcher",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80"
  },
  settings: {
    pathogenicityThreshold: 0.65,
    revelWeight: 0.30,
    caddWeight: 0.25,
    gnomadWeight: 0.20,
    polyphenWeight: 0.15,
    siftWeight: 0.10,
    activeModel: "OncoSage-XGBoost Neural V3"
  }
};
