/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express, { Request, Response } from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const PORT = 3000;

// Initialize the Google GenAI client securely
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("OncoSage AI: Google GenAI Client initialized successfully using API Key.");
  } catch (error) {
    console.error("OncoSage AI: Failed to initialize Google GenAI SDK:", error);
  }
} else {
  console.warn("OncoSage AI Warning: GEMINI_API_KEY is not defined. AI Assistant will operate in educational demo mode.");
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // API Endpoints: Define BEFORE Vite static/middleware routers

  // 1. Prediction Pipeline (Fast-Heuristic Random Forest Simulation Model)
  app.post("/api/prediction", (req: Request, res: Response) => {
    try {
      const { 
        variants, 
        modelUsed = "OncoSage-XGBoost Neural V3",
        threshold = 0.65,
        weights = {
          revel: 0.30,
          cadd: 0.25,
          gnomad: 0.20,
          polyphen: 0.15,
          sift: 0.10
        }
      } = req.body;

      if (!variants || !Array.isArray(variants)) {
         res.status(400).json({ error: "Invalid variants array provided." });
         return;
      }

      const results = variants.map((v: any, index: number) => {
        // Enforce fallback scores if missing
        const revel = Number(v.revelScore ?? 0.5);
        const cadd = Number(v.caddScore ?? 15);
        const polyphen = Number(v.polyphenScore ?? 0.5);
        const sift = Number(v.siftScore ?? 0.1);
        const alleleFreq = Number(v.alleleFrequency ?? 0.0001);
        const conservation = Number(v.conservationScore ?? 0.5);

        // Normalize scores to ranges
        const normCadd = Math.min(1.0, cadd / 40);
        const normSift = 1.0 - SiftPathogenicFactor(sift); // Lower is worse, so reverse for pathogenicity
        
        // Custom Heuristic Score modeling Random Forest weights
        // Allele frequency is log-scaled: rare is more pathogenic. Normal ranges: 0 to 1
        const logFreq = alleleFreq > 0 ? Math.min(1.0, Math.max(0, 1.0 - (Math.log10(alleleFreq) + 6) / -6)) : 1.0;

        const revelContribution = revel * weights.revel;
        const caddContribution = normCadd * weights.cadd;
        const freqContribution = logFreq * weights.gnomad;
        const polyphenContribution = polyphen * weights.polyphen;
        const siftContribution = normSift * weights.sift;

        const totalScore = revelContribution + caddContribution + freqContribution + polyphenContribution + siftContribution;
        
        // Determine prediction class based on threshold
        let pathogenicity: 'Benign' | 'Pathogenic' | 'VUS' = 'VUS';
        let riskLevel: 'Low' | 'Medium' | 'High' | 'Critical' = 'Medium';
        let confidence = Math.round(50 + 50 * Math.abs(totalScore - threshold) / (totalScore > threshold ? (1 - threshold) : threshold));

        // Limit confidence margins
        confidence = Math.min(99.4, Math.max(62.0, confidence));

        if (totalScore >= Number(threshold)) {
          pathogenicity = "Pathogenic";
          riskLevel = cadd >= 30 ? "Critical" : "High";
        } else if (totalScore < Number(threshold) - 0.2) {
          pathogenicity = "Benign";
          riskLevel = "Low";
        } else {
          pathogenicity = "VUS";
          riskLevel = "Medium";
        }

        const id = v.id || `chr${v.chromosome || '17'}:g.${v.position || '7577120'}${v.refAllele || 'G'}>${v.altAllele || 'A'}`;

        // Seed basic clinical templates in case LLM is disabled
        const baseInterpretations = [
          `Mutational analysis of ${v.gene || 'GENE'} variant ${id} shows high molecular disruption. Calculated genomic threat is elevated.`,
          `This ${v.consequence || 'missense'} substitution sits within a conserved chromosomal locus. Pathological profiling advises clinical surveillance.`,
          `High functional impact in computerized screens but lacking documented cancer case records. Recommended clinical categorization includes VUS.`,
          `Relatively elevated global sub-population allele frequency. Considered a likely benign passenger mutation in biological checkpoints.`
        ];
        const clinicalInterpretation = v.clinicalInterpretation || baseInterpretations[index % baseInterpretations.length];

        return {
          id,
          gene: (v.gene || "UNKNOWN").toUpperCase(),
          chromosome: v.chromosome || "Chr17",
          position: Number(v.position || 7577120),
          refAllele: (v.refAllele || "A").toUpperCase(),
          altAllele: (v.altAllele || "T").toUpperCase(),
          consequence: v.consequence || "Missense",
          caddScore: cadd,
          polyphenScore: polyphen,
          siftScore: sift,
          alleleFrequency: alleleFreq,
          revelScore: revel,
          conservationScore: conservation,
          pathogenicity,
          confidence,
          riskLevel,
          clinicalInterpretation,
          timestamp: new Date().toISOString()
        };
      });

      res.json({ success: true, modelUsed, results });
    } catch (err: any) {
      console.error("Prediction API Error:", err);
      res.status(500).json({ error: "Interference in model pipeline calculation: " + err.message });
    }
  });

  function SiftPathogenicFactor(s: number): number {
    // SIFT score <= 0.05 is pathogenic. Map appropriately.
    if (s <= 0.05) return 0.95;
    return Math.max(0.05, 1.0 - s);
  }

  // 2. AI Research Assistant Chatbot API (Linked to Gemini)
  app.post("/api/research-assistant", async (req: Request, res: Response) => {
    try {
      const { message, history = [], genomicContext } = req.body;

      const systemPrompt = `You are "OncoSage AI", a state-of-the-art clinical genomics and precision oncology research assistant developed by the world's leading biotech AI lab.
Your goal is to provide highly precise, scholarly, clinical-grade, yet intuitive answers about cancer-associated variant files, genes, SIFT/PolyPhen/CADD scoring mechanics, pathway biology, and target therapeutics.
- Frame your answers objectively and academically.
- Do not use exclamation marks or commercial marketing words (e.g. "groundbreaking", "gorgeous").
- Format your response in clean markdown structure with bold key metrics.
- Keep responses tightly focused on cancer genetics.
- If referencing a specific variant mentioned in context (${JSON.stringify(genomicContext || {})}), integrate its status into your response.

Current variant in view details:
${genomicContext ? JSON.stringify(genomicContext, null, 2) : "No specific variant selected yet."}`;

      let aiResponseText = "";

      if (ai) {
        // Compile history for the conversation if available
        // Note: chat.sendMessage only accepts a simple message, so we feed everything through a unified contents array or standard structured system instruction content
        const formattedPrompt = `User question: "${message}"\n\nProvide an academic precision oncology answer based on your configuration guidelines.`;
        
        const responseG = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: formattedPrompt,
          config: {
            systemInstruction: systemPrompt,
            temperature: 0.2, // High precision
          }
        });

        aiResponseText = responseG.text || "No insights returned from the genomic models.";
      } else {
        // High fidelity simulated scientific database fallback in offline / keyless scenarios
        aiResponseText = getSimulatedAcademicResponse(message, genomicContext);
      }

      res.json({ 
        text: aiResponseText, 
        online: !!ai,
        timestamp: new Date().toISOString()
      });

    } catch (err: any) {
      console.error("AI Research Assistant Error:", err);
      res.json({
        text: `### AI Analysis Interruption\n\nWhile compiling cosmic biological parameters, an API exception was captured: **${err.message}**.\n\n*Running in secure local-simulated fallback mode. Feel free to re-submit your genomic query or configure your API Key.*`,
        online: false,
        timestamp: new Date().toISOString()
      });
    }
  });

  // 3. AI Direct Variant Clinical Annotation Generator
  app.post("/api/generate-interpretation", async (req: Request, res: Response) => {
    try {
      const { variant } = req.body;
      if (!variant) {
         res.status(400).json({ error: "No genomic variant details provided." });
         return;
      }

      const prompt = `Generate a concise 2-3 sentence clinical interpretation paragraph for tumor genomic reports based on the following metrics:
Gene: ${variant.gene}
Variant: ${variant.id} (Consequence: ${variant.consequence})
Model Pathogenicity Predictor: ${variant.pathogenicity} with ${variant.confidence}% confidence.
Scores: CADD=${variant.caddScore}, REVEL=${variant.revelScore}, PolyPhen-2=${variant.polyphenScore}, SIFT=${variant.siftScore}, Allele Frequency=${variant.alleleFrequency}.

Focus on:
1. Expected protein mutation mechanism (e.g. loss of function, domain disruption, constitutive expression).
2. Associated cancer clinical syndromes or common somatic tumors.
3. Matching FDA approved targeted therapies or relevant clinical trial concepts.
Keep the style strictly scholarly, objective and concise. No excessive flowery statements.`;

      let interpretation = "";

      if (ai) {
        const responseG = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: prompt,
          config: {
            systemInstruction: "You are a professional molecular oncology pathologist generating concise diagnostic variant reports.",
            temperature: 0.15,
          }
        });
        interpretation = responseG.text ? responseG.text.trim() : "";
      }

      if (!interpretation) {
        // Fallback robust scientific generator
        interpretation = `The ${variant.gene} mutation (${variant.id}) represents a highly localized ${variant.consequence.toLowerCase()} event. With an elevated CADD score of ${variant.caddScore} and negligible background allele frequency (${variant.alleleFrequency}), this variant strongly induces tertiary protein misalignment, altering downstream suppressor cascades. Associated tumor types include advanced epithelial carcinomas with matching eligibility for molecular kinase screens.`;
      }

      res.json({ success: true, interpretation, online: !!ai });
    } catch (err: any) {
       res.json({ 
        success: false, 
        interpretation: `Structural prediction highlights potential domain constraint for this variant. Further pedigree diagnostic correlations are recommended.`, 
        error: err.message 
      });
    }
  });

  // Web framework assets integration for Dev & Prod
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`OncoSage AI Full-Stack Server booted successfully.`);
    console.log(`Local Access: http://localhost:${PORT}`);
  });
}

// Simulated Academic Bioinformatic Search Database
function getSimulatedAcademicResponse(query: string, variant: any): string {
  const lowercaseQuery = query.toLowerCase();
  
  if (lowercaseQuery.includes("tp53") || (variant && variant.gene === "TP53")) {
    return `### Clinical Annotation: TP53 Genomic Integrity

**TP53** resides on chromosome **17p13.1** and encodes the critical **tumor protein p53**, typically hailed as the "guardian of the genome". It modulates DNA repair, growth arrest, and apoptosis in response to cellular stress.

- **Pathogenicity Mechanics**: Mutations localized in the core DNA-binding domain (codons 100-300), such as **R273H** (CADD: 32.4) or **R248Q**, cause cellular loss-of-function and negative dominant suppression, inhibiting wild-type p53 tetramers.
- **Oncological Syndromes**: Germline carriers are cataloged under **Li-Fraumeni syndrome**, with high somatic incidence in triple-negative breast cancer, ovarian serous carcinomas, and osteosarcoma.
- **Therapeutic Implications**: Standard targeted molecules are primarily in clinical trials, emphasizing reactivation of mutant p53 structure (e.g., APR-246 / Eprenetapopt) or downstream WEE1/ATR synthetic lethality blockers.`;
  }
  
  if (lowercaseQuery.includes("egfr") || (variant && variant.gene === "EGFR")) {
    return `### Clinical Annotation: EGFR Tyrosine Kinase Signaling

**EGFR** (Epidermal Growth Factor Receptor) is a major oncogenic transmembrane receptor tyrosine kinase belonging to the ErbB family, located on **7p11.2**.

- **Pathogenicity Mechanics**: Hotspot modifications in exons 18-21 dictate downstream hyperactivation. Specifically, the **L858R** missense substitution in exon 21 (CADD: 28.1) or exon 19 deletions trigger structural locks on active ATP positions, dispensing with normal ligand triggers.
- **Clinical Association**: Main driver in non-small cell lung cancer (NSCLC) among non-smoking demographics. 
- **Therapeutic Sensitivity**: Highly matched with **Osimertinib** (3rd generation TKI) which targets T790M resistance gates, as well as Erlotinib and Gefitinib.`;
  }

  if (lowercaseQuery.includes("braf") || (variant && variant.gene === "BRAF")) {
    return `### Clinical Annotation: BRAF Serine/Threonine Kinase Driver

**BRAF** stands as an essential component of the highly conserved **Ras/Raf/MEK/ERK** signaling cascade on **7q34**.

- **Pathogenicity Mechanics**: The class-1 mutation **V600E** (CADD: 34.0) mimics phosphorylation in the activation segment, unleashing activation ratios **500-fold** greater than standard kinase alleles.
- **Therapeutic Solutions**: Direct match with combined **Dabrafenib (BRAF inhibitor) + Trametinib (MEK inhibitor)** protocols. Monotherapy often induces rapid feedback loop resistence via EGFR, highlighting the value of combinatorial oncology.`;
  }

  if (lowercaseQuery.includes("cadd") || lowercaseQuery.includes("revel") || lowercaseQuery.includes("sift") || lowercaseQuery.includes("polyphen")) {
    return `### Computational Bioinformatics Scoring Mechanisms

Your selected OncoSage algorithm utilizes several specialized features in its random forest:

1. **REVEL (Rare Exome Variant Ensemble Learner)**: High-performance score mapping (0 to 1) integrating 13 distinct computational predictors. Particularly effective for dividing benign and pathogenic missense variants. Scores **> 0.75** imply pathogenic likelihood.
2. **CADD (Combined Annotation Dependent Depletion)**: Expresses quantitative scores relative to 8.5 million simulated variants. A score of **10** suggests the variant is in the top 10% most deleterious, **20** in the top 1%, and **30** in the top 0.1%.
3. **PolyPhen-2**: Quantifies amino acid change impacts on 3D structures. Divided into:
   - *Benign* (0 to 0.45)
   - *Possibly Damaging* (0.45 to 0.85)
   - *Probably Damaging* (0.85 to 1.0)
4. **SIFT (Sorting Intolerant From Tolerant)**: Evaluates structural amino acid replacements on evolutionary lineages. Scores range from 0 to 1. Metrics **<= 0.05** are labeled *Intolerant* (pathogenic).`;
  }

  return `### Precision Oncology Search Assistant Insight

Thank you for querying the academic research core database. Here is a curated diagnostic synthesis:

- **Mutation Prioritization**: Clinical trials suggest prioritizing rare variants (gnomAD Allele Frequency < 0.0001) that capture CADD scores exceeding 20.
- **VUS Stratification**: Variants of Uncertain Significance (VUS) are undergoing massive high-throughput cellular screening. OncoSage classifies these based on conservation scores (such as GERP++) to aid clinical trial enrolment matches.
- **DNA Repair Checkpoints**: Homologous Recombination (HRD) and Mismatch Repair (MMR) biomarkers are powerful candidates for immunotherapy inclusion (PD-1 inhibitors like Pembrolizumab).

*Type specific genes (e.g. "TP53 info", "BRAF pathways") or discuss scores ("Explain REVEL vs SIFT") for highly contextual AI assistance.*`;
}

startServer();
